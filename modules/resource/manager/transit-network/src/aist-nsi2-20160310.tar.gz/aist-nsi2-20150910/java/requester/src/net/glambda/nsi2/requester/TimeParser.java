/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TimeParser {

    private static final String DATE_RX = "([0-9]{4}+)-([0-9]{2}+)-([0-9]{2}+)";
    private static final String TIME_RX = "([0-9]{2}+):([0-9]{2}+):([0-9]{2}+)";
    private static final String TIMEZONE_RX = "Z|([+-][0-9]{2}+):([0-9]{2}+)";

    private static final Pattern TIME = Pattern.compile(TIME_RX);
    private static final Pattern FULL = Pattern.compile(DATE_RX + "T" + TIME_RX + "(" + TIMEZONE_RX
            + ")?");

    public static String supportedFormat() {
        return "\"HH:MM:SS\", \"yyyy-mm-ddTHH:MM:SS\", \"yyyy-mm-ddTHH:MM:SSZ\", \"yyyy-mm-ddTHH:MM:SS[+-]hh:mm\"";
    }

    // Supported Format:
    // "12:34:56" (assume today, and local TimeZone)
    // "2013-08-08T12:34:56" (local TimeZone)
    // "2013-08-08T12:34:56Z" (GMT)
    // "2013-08-08T12:34:56GMT+09:00"
    public static Calendar parse(String txt) {
        if (txt == null) {
            return null;
        }
        Calendar c;
        Matcher m = TIME.matcher(txt);
        if (m.matches()) {
            c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(m.group(1)));
            c.set(Calendar.MINUTE, Integer.parseInt(m.group(2)));
            c.set(Calendar.SECOND, Integer.parseInt(m.group(3)));
            c.set(Calendar.MILLISECOND, 0);
            return c;
        }
        m = FULL.matcher(txt);
        if (m.matches()) {
            String tz = m.group(7);
            if (tz != null && !tz.isEmpty()) {
                if (tz.equals("Z")) {
                    c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
                } else {
                    c = Calendar.getInstance(TimeZone.getTimeZone("GMT" + m.group(8) + m.group(9)));
                }
            } else {
                c = Calendar.getInstance();
            }
            c.set(Calendar.YEAR, Integer.parseInt(m.group(1)));
            // NOTE: 0=January
            c.set(Calendar.MONTH, Integer.parseInt(m.group(2)) - 1);
            c.set(Calendar.DAY_OF_MONTH, Integer.parseInt(m.group(3)));
            c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(m.group(4)));
            c.set(Calendar.MINUTE, Integer.parseInt(m.group(5)));
            c.set(Calendar.SECOND, Integer.parseInt(m.group(6)));
            c.set(Calendar.MILLISECOND, 0);
            return c;
        } else {
            return null;
        }
    }

    public static void main(String args[]) {
        System.out.println(String.format(Locale.US, "%tc", Calendar.getInstance()));
        System.out.println(String.format(Locale.US, "%tc", parse("12:34:56")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56Z")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56+09:00")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56-09:00")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56-00:00")));
        System.out.println(String.format(Locale.US, "%tc", parse("2013-08-09T12:34:56-02:30")));
    }
}
