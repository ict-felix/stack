/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.TimerTask;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import net.glambda.nsi2.impl.EventListener;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.TopologyLoader;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.TypesBuilder;
import nsi2.reply.QueryNotificationReply;
import nsi2.reply.QueryReply;
import nsi2.reply.ReserveCommitReply;
import nsi2.reply.ReserveReply;

import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;


public class AutomaticRequester {

    private void showMessage(String header, String txt) {
        System.out.println("**** " + header + " ****");
        System.out.println(txt);
        System.out.println();
    }

    private void showMessage(Object o, String txt) {
        if (o != null) {
            showMessage(o.getClass().getSimpleName(), txt);
        } else {
            showMessage("", txt);
        }
    }

    private static final long DEFAULT_CAPACITY = 100; // [Mbps]
    private static final int START_OFFSET = 1; // [min]
    private static final int END_OFFSET = 4; // [min]
    private static final int TERMINATE_OFFSET = 240000; // [msec] (= 240 [sec])
    private static final int RSV_INTERVAL = 200000; // [msec] (= 200 [sec])
    private static final int SLEEP_DURATION = 2000; // [msec] (= 2 [sec])
	private static final long MAX_DURATION = 86400000; //24hours
    
    private static int[] vlans = {1779, 1780, 1781, 1782};
    private LinkedList<NSA> nsaList;
    private HashMap<String,String> endpoints = new HashMap<String, String>();
    private LinkedList<String> networkIds = new LinkedList<String>(); 
    
    private void initTopology() {
    	try {
			nsaList = TopologyLoader.loadAll();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Topology loading has failed.");
			System.exit(0);
		}
    	for (NSA nsa : nsaList){
    		String netId = nsa.ets();
    		for (STP bi : nsa.biStps()) {
    			String stpid = bi.stpid();
    			if (stpid.contains("bi-ps")) {
    				endpoints.put(netId, stpid);
    				networkIds.add(netId);
    				System.out.println("bi-ps endpoint: " + netId + " - " + stpid);
    				break;
    			}
    		}
    	}
    }
    
    private class Pair {
    	String srcNetworkId;
        String srcLocalId;
        String destNetworkId;
        String destLocalId;
    }
    
    Random random = new Random();
    private Pair selectConnection() {
    	String srcNet = networkIds.get(Math.abs(random.nextInt()) % networkIds.size());
    	String destNet = null;
    	while (destNet == null) {
    		destNet = networkIds.get(Math.abs(random.nextInt()) % networkIds.size());
    		if (destNet.equals(srcNet)) {
    			destNet = null;
    			continue;
    		}
    	}
    	Pair pair = new Pair();
    	pair.srcNetworkId = srcNet;
    	pair.srcLocalId = endpoints.get(srcNet);
    	pair.destNetworkId = destNet;
    	pair.destLocalId = endpoints.get(destNet);

    	if (true) {
        	pair.srcNetworkId = "urn:ogf:network:aist.go.jp:2013:topology";
        	pair.srcLocalId = "urn:ogf:network:aist.go.jp:2013:topology:bi-ps";
        	pair.destNetworkId = "urn:ogf:network:kddilabs.jp:2013:topology";
        	pair.destLocalId = "urn:ogf:network:kddilabs.jp:2013:topology:bi-ps";
    	}
    	if (false) {
        	pair.srcNetworkId = "urn:ogf:network:kddilabs.jp:2013:topology";
        	pair.srcLocalId = "urn:ogf:network:kddilabs.jp:2013:topology:bi-ps";
        	pair.destNetworkId = "urn:ogf:network:krlight.net:2013:topology";
        	pair.destLocalId = "urn:ogf:network:krlight.net:2013:topology:bi-ps";
    	}
 		return pair;
 	}

    private int index = 0;
    private int getVlan() {
    	index = (index + 1) % vlans.length;
   		return vlans[index];
   	}

    private ReservationRequestCriteriaType makeDummyReservationRequestCriteriaType(Pair p, int vlan) {
        // NOTE: These are DUMMY values for test
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        start.add(Calendar.MINUTE, START_OFFSET);
        end.add(Calendar.MINUTE, END_OFFSET);
        long capacity = DEFAULT_CAPACITY;
        
        ScheduleType schedule = TypesBuilder.makeScheduleType(start, end);
        String srcstp = TypesBuilder.makeStpId(p.srcNetworkId, p.srcLocalId);
        String deststp = TypesBuilder.makeStpId(p.destNetworkId, p.destLocalId);
        ReservationRequestCriteriaType crit = TypesBuilder.makeReservationRequestCriteriaType(
        		schedule, srcstp, vlan, deststp, vlan, capacity);
        crit.setVersion(currentVersion);
        return crit;
    }

	// DUMMY VALUE, can be null
    //private final String DEFAULT_GLOBAL_RESERVATION_ID = "global";
    private final String DEFAULT_GLOBAL_RESERVATION_ID = null;
    // DUMMY VALUE, can be null
    private final String DEFAULT_DESCRIPTION = "nsi2 test";

    private int currentVersion = 0;

    private String testFirstReserve(NSI2Client client, Pair p, int vlan) throws Exception {
        // NOTE: connectionId must be null for first reservation
        String connectionId = null;
        String globalReservationId = DEFAULT_GLOBAL_RESERVATION_ID;
        //String description = DEFAULT_DESCRIPTION;
        String description = getDesc(p, vlan);
        ReservationRequestCriteriaType criteria = makeDummyReservationRequestCriteriaType(p, vlan);
        showMessage(criteria, NSITextDump.toString(criteria));

        ReserveReply reply =
                client.reserve(connectionId, globalReservationId, description, criteria);

        if (reply.getConfirm() != null) {
            ReservationConfirmCriteriaType conf = reply.getConfirm();
            showMessage("ConnectionID", reply.getConnectionId());
            showMessage(conf, NSITextDump.toString(conf));
            currentVersion = conf.getVersion();
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
        return reply.getConnectionId();
    }

    private int getNewVersion() {
        currentVersion++;
        return currentVersion;
    }

    private void testReserveCommit(NSI2Client client, String connectionId) throws Exception {
        ReserveCommitReply reply = client.reserveCommit(connectionId);
        if (reply.getServiceException() == null) {
            System.out.println("ReserveCommitConfirmed");
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
    }

    private void testReserveAbort(NSI2Client client, String connectionId) throws Exception {
        client.reserveAbort(connectionId);
    }

    private void testModify(NSI2Client client, String connectionId, Calendar start, Calendar end,
            long capacity, int version) throws Exception {
        String globalReservationId = DEFAULT_GLOBAL_RESERVATION_ID;
        String description = DEFAULT_DESCRIPTION;
        ScheduleType schedule;
        if (start != null || end != null) {
            // modify schedule
            schedule = TypesBuilder.makeScheduleType(start, end);
        } else {
            schedule = null;
        }
        ReservationRequestCriteriaType criteria;
        if (capacity > 0) {
            // modify capacity (and schedule if it's specified)
            criteria = TypesBuilder.makeReservationRequestCriteriaType(schedule, capacity);
        } else {
            System.out.println("nothing specified to be modified");
            return;
        }
        criteria.setVersion(version);
        showMessage(criteria, NSITextDump.toString(criteria));

        ReserveReply reply =
                client.reserve(connectionId, globalReservationId, description, criteria);

        if (reply.getConfirm() != null) {
            ReservationConfirmCriteriaType conf = reply.getConfirm();
            showMessage(conf, NSITextDump.toString(conf));
            currentVersion = conf.getVersion();
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
    }

    private void testQuery(NSI2Client client, String connectionId) throws Exception {
        QueryType queryType = new QueryType();
        queryType.getConnectionId().add(connectionId);
        {
            // QuerySummarySync
            QuerySummaryConfirmedType summary = client.querySummarySync(queryType);
            showMessage("QuerySummary (sync)", NSITextDump.toString(summary));
        }
        if (hasRequester) {
            // QuerySummary (async)
            QueryReply reply = client.querySummary(queryType);
            if (reply.getSummary() != null) {
                List<QuerySummaryResultType> summary = reply.getSummary();
                showMessage("QuerySummary (async)", NSITextDump.toStringQuerySummayList(summary));
            } else {
                showMessage("QuerySummary (async)", NSITextDump.toString(reply.getException()));
            }
        }
        if (hasRequester) {
            // QueryRecursive (async)
            QueryReply reply = client.queryRecursive(queryType);
            if (reply.getRecursive() != null) {
                List<QueryRecursiveResultType> recursive = reply.getRecursive();
                showMessage("QueryRecursive (async)",
                        NSITextDump.toStringQueryRecursiveList(recursive));
            } else {
                showMessage("QueryRecursive (async)", NSITextDump.toString(reply.getException()));
            }
        }
    }

    private void testQueryNotification(NSI2Client client, String connectionId) throws Exception {
        QueryNotificationType type = new QueryNotificationType();
        type.setConnectionId(connectionId);
        {
            // QueryNotification (sync)
            QueryNotificationConfirmedType conf = client.queryNotificationSync(type);
            showMessage("QueryNotification (sync)", NSITextDump.toString(conf));
        }
        if (hasRequester) {
            // QueryNotification (async)
            QueryNotificationReply reply = client.queryNotification(type);
            if (reply.getConfirmed() != null) {
                showMessage("QueryNotification (async)", NSITextDump.toString(reply.getConfirmed()));
            } else {
                showMessage("QueryNotification (async)", NSITextDump.toString(reply.getException()));
            }
        }
    }

    private boolean hasRequester = false;

    private NSI2Client makeClient(String[] args) throws Exception {
        String providerNSA = args[0];
        String providerURI = args[1];
        String requesterNSA = args[2];
        String requesterURI;
        if (args[3].equals("-")) {
            requesterURI = null;
            System.out.println("replyTo will be null. You must use QuerySync to get status");
        } else {
            requesterURI = args[3];
            hasRequester = true;
        }
        long replyWaitMsec = 60 * 1000L; // [msec]
        
        
        String httpUser, httpPassword;
        if (args.length == 6) {
            httpUser = args[4];
            httpPassword = args[5];
        } else {
            httpUser = httpPassword = null;
        }
        // listener can be null if you don't want it
        EventListener listener = new SampleEventListener();
        //final String OAuth = "68031d39-6646-4f29-b939-56907107167c"; // "44e53ca6-5b48-4503-b605-388e48085b36"; // null
        //return new NSI2Client(providerNSA, providerURI, requesterNSA, requesterURI, replyWaitMsec, OAuth, listener);
        return new NSI2Client(providerNSA, providerURI, requesterNSA, requesterURI, replyWaitMsec,
                httpUser, httpPassword, listener);
    }

    static int serial = 0;
    class RsvTask extends TimerTask {
    	NSI2Client client;
    	Timer timer;
    	
    	RsvTask(NSI2Client client) {
    		this.client = client;
    	}
    	
    	public void run() {
    		int id = serial++;
    		try {
    	        Pair p = selectConnection();
    	        int vlan = getVlan();

                // first reserve & commit
                printMsg("first reserve", id, p, vlan);
                String connectionId = testFirstReserve(client, p, vlan);
                Thread.sleep(SLEEP_DURATION);
                // commit
                printMsg("commit", id, p, vlan);
                testReserveCommit(client, connectionId);
                Thread.sleep(SLEEP_DURATION);
                // provision
                printMsg("provision", id, p, vlan);
                client.provision(connectionId);
                Thread.sleep(TERMINATE_OFFSET);
                // terminate
                printMsg("terminate", id, p, vlan);
                client.terminate(connectionId);
    		} catch (Exception e) {
    			e.printStackTrace();
    		}
    	}
    }
    
    private String getDesc(Pair p, int vlan) {
    	return p.srcLocalId + "-" + p.destLocalId + ":" + vlan;
    }
    
    private void printMsg(String msg, int id, Pair p, int vlan) {
    	System.out.println("========== " + id + " (" + vlan + " : " + p.srcLocalId + " - " +
    						p.destLocalId + ") : " + msg + " ==========");
	}
    
    
    private void test(String[] args) throws Exception {
    	System.out.println("***** initTopology *****");
    	initTopology();
    	System.out.println("***** make client *****");
    	NSI2Client client = makeClient(args);

    	System.out.println("***** start timer *****");
    	Timer timer = new Timer();
    	TimerTask task = new RsvTask(client);
    	timer.schedule(task, 0, RSV_INTERVAL);
    	TimeUnit.SECONDS.sleep(MAX_DURATION);
    	timer.cancel();
    }
    
    public static void main(String[] args) {
        if (args.length < 4) {
            System.err.println("Usage: java ClientTest2 providerNSA providerURI"
                    + " requesterNSA {requesterURI|-} [httpUser httpPassword]");
            System.exit(1);
        }
        AutomaticRequester app = new AutomaticRequester();
        try {
            app.test(args);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // NOTE: Endpoint.stop() doesn't stop all threads in CXF, so we must
        // call this at the end to stop requester port.
        System.exit(0);
    }

}
