/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Arrays;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.ws.Endpoint;

import net.glambda.nsi2.impl.NSIProperties;

import org.apache.commons.logging.Log;
import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.bus.spring.SpringBusFactory;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.jsse.TLSServerParameters;
import org.apache.cxf.configuration.security.ClientAuthentication;
import org.apache.cxf.configuration.security.FiltersType;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transport.http_jetty.JettyHTTPServerEngineFactory;

public class SecurityUtil {

    protected static final Log logger = AbstractLog.getLog(SecurityUtil.class);
    private static final NSIProperties nsiProp = NSIProperties.getInstance();

    public static final String SSL_KEY_FILE = nsiProp.getProperty(NSIProperties.PROP_SSL_KEY_FILE);
    public static final String SSL_KEY_STORE_PASS = nsiProp
            .getProperty(NSIProperties.PROP_SSL_KEY_STORE_PASS);
    public static final String SSL_KEY_PASS = nsiProp.getProperty(NSIProperties.PROP_SSL_KEY_PASS);
    public static final String SSL_TRUST_FILE = nsiProp
            .getProperty(NSIProperties.PROP_SSL_TRUST_FILE);
    public static final String SSL_TRUST_STORE_PASS = nsiProp
            .getProperty(NSIProperties.PROP_SSL_TRUST_STORE_PASS);
    public static final boolean HAS_SSL = (SSL_KEY_FILE != null && SSL_KEY_STORE_PASS != null
            && SSL_KEY_PASS != null && SSL_TRUST_FILE != null && SSL_TRUST_STORE_PASS != null);

    static {
        if (HAS_SSL) {
            logger.info("SSL_KEY_FILE=" + SSL_KEY_FILE);
            logger.info("SSL_KEY_STORE_PASS=" + SSL_KEY_STORE_PASS);
            logger.info("SSL_KEY_PASS=" + SSL_KEY_PASS);
            logger.info("SSL_TRUST_FILE=" + SSL_TRUST_FILE);
            logger.info("SSL_TRUST_STORE_PASS=" + SSL_TRUST_STORE_PASS);
            try {
                SSLContext context = SSLContext.getInstance("TLS");
                context.init(null, null, null);
                SSLSocketFactory factory = (SSLSocketFactory) context.getSocketFactory();
                SSLSocket socket = (SSLSocket) factory.createSocket();
                logger.info("supported protocols: "
                        + Arrays.toString(socket.getSupportedProtocols()));
                logger.info("enabled protocols: " + Arrays.toString(socket.getEnabledProtocols()));
            } catch (Exception e) {
                logger.warn(e);
            }
        }
    }

    @Deprecated
    public static void setTLSServerParameters(int port) throws Exception {
        // NOTE: not works with CXF 2.7.10....
        TLSServerParameters tlsParams = new TLSServerParameters();
        System.err.println(tlsParams.getSecureSocketProtocol());
        KeyStore keyStore = KeyStore.getInstance("JKS");
        File keystoreFile = new File(SecurityUtil.SSL_KEY_FILE);
        keyStore.load(new FileInputStream(keystoreFile),
                SecurityUtil.SSL_KEY_STORE_PASS.toCharArray());
        KeyManagerFactory keyFactory =
                KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyFactory.init(keyStore, SecurityUtil.SSL_KEY_PASS.toCharArray());
        KeyManager[] km = keyFactory.getKeyManagers();
        tlsParams.setKeyManagers(km);
        //
        File truststoreFile = new File(SecurityUtil.SSL_TRUST_FILE);
        keyStore.load(new FileInputStream(truststoreFile),
                SecurityUtil.SSL_TRUST_STORE_PASS.toCharArray());
        TrustManagerFactory trustFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustFactory.init(keyStore);
        TrustManager[] tm = trustFactory.getTrustManagers();
        tlsParams.setTrustManagers(tm);
        FiltersType filter = new FiltersType();
        filter.getInclude().add(".*_EXPORT_.*");
        filter.getInclude().add(".*_EXPORT1024_.*");
        filter.getInclude().add(".*_WITH_DES_.*");
        filter.getInclude().add(".*_WITH_NULL_.*");
        filter.getExclude().add(".*_DH_anon_.*");
        tlsParams.setCipherSuitesFilter(filter);
        ClientAuthentication ca = new ClientAuthentication();
        ca.setRequired(false);
        ca.setWant(false);
        tlsParams.setClientAuthentication(ca);
        JettyHTTPServerEngineFactory factory = new JettyHTTPServerEngineFactory();
        factory.setTLSServerParametersForPort(port, tlsParams);
    }

    private static TrustManager[] getTrustManagers(KeyStore trustStore) throws Exception {
        String alg = KeyManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory fac = TrustManagerFactory.getInstance(alg);
        fac.init(trustStore);
        return fac.getTrustManagers();
    }

    private static KeyManager[] getKeyManagers(KeyStore keyStore, String keyPassword)
            throws Exception {
        String alg = KeyManagerFactory.getDefaultAlgorithm();
        char[] keyPass = keyPassword != null ? keyPassword.toCharArray() : null;
        KeyManagerFactory fac = KeyManagerFactory.getInstance(alg);
        fac.init(keyStore, keyPass);
        return fac.getKeyManagers();
    }

    public static void initClientTLS(Object port) {
        if (port == null || !HAS_SSL) {
            return;
        }
        logger.info("init client TLS");
        // apache-cxf-2.7.10/samples/wsdl_first_https/src/main/java/demo/hw_https/client/ClientNonSpring.java
        try {
            HTTPConduit httpConduit = (HTTPConduit) ClientProxy.getClient(port).getConduit();

            TLSClientParameters tlsCP = new TLSClientParameters();
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(new FileInputStream(SSL_KEY_FILE), SSL_KEY_STORE_PASS.toCharArray());
            KeyManager[] myKeyManagers = getKeyManagers(keyStore, SSL_KEY_PASS);
            tlsCP.setKeyManagers(myKeyManagers);

            KeyStore trustStore = KeyStore.getInstance("JKS");
            trustStore
                    .load(new FileInputStream(SSL_TRUST_FILE), SSL_TRUST_STORE_PASS.toCharArray());
            TrustManager[] myTrustStoreKeyManagers = getTrustManagers(trustStore);
            tlsCP.setTrustManagers(myTrustStoreKeyManagers);
            // tlsCP.setSecureSocketProtocol("TLSv1.2");
            httpConduit.setTlsClientParameters(tlsCP);
        } catch (Exception e) {
            logger.fatal("CANNOT INIT CLIENT TLS");
            logger.error(e);
            e.printStackTrace();
            logger.fatal("ABORT PROGRAM NOW!");
            System.exit(1);
        }
    }

    public static final String HTTPS_CONFIG_XML = "/etc/ServerConfig.xml";

    public static void publish(String address, Object implementor) {
        publish(address, implementor, HTTPS_CONFIG_XML);
    }

    public static void publish(String address, Object implementor, String filename) {
        // NOTE: filename must be "/xxx/xxxx.xml" [archived in a jar file in
        // classpath] or "file:/home/demo/.../xxxx.xml" (a regular file on
        // a filesystem, must use absolute path)
        if (address == null || implementor == null) {
            throw new NullPointerException();
        }
        try {
            if (address.startsWith("https")) {
                SpringBusFactory bf = new SpringBusFactory();
                Bus bus = bf.createBus(filename);
                BusFactory.setDefaultBus(bus);
            }
            Endpoint.publish(address, implementor);
        } catch (Exception e) {
            logger.fatal("CANNOT PUBLISH " + implementor.getClass().getCanonicalName() + " at "
                    + address);
            logger.error(e);
            e.printStackTrace();
            logger.fatal("ABORT PROGRAM NOW!");
            System.exit(1);
        }
    }

}
