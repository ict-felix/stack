Firefoxでサイトを開く
	https://nsi.nordu.net:9443/NSI/topology/nordu.net:2013.xml

証明書を表示する
	認証局名をクリックの上、証明書をエクスポートする (nordu.pem)

	nordu.pem の内容確認
	> openssl x509 -text -in nordu.pem

	コマンドラインでもできる	
	http://serverfault.com/questions/139728/how-to-download-ssl-certificate-from-a-website
	
	echo -n | openssl s_client -connect nsi.nordu.net:9443 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > nordu.pem
	echo -n | openssl s_client -connect oscars.es.net:443 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > oscars.pem
	echo -n | openssl s_client -connect bod.netherlight.net:443 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > netherlight.pem
	echo -n | openssl s_client -connect 203.30.39.121:8500 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > singaren.pem
	echo -n | openssl s_client -connect oscars.manlan.internet2.edu:8500 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > manlan.pem
	echo -n | openssl s_client -connect nsa.uvalight.net:9443 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > uvalight.pem

公式証明書のコピー
	cp /usr/java/latest/jre/lib/security/cacerts nsi-trust.jks
	
	公式証明書の storepass は changeit
	
証明書の取り込み
	$ keytool -import -alias nordu -storepass changeit -noprompt -file nordu.pem -keystore nsi-trust.jks
	$ keytool -import -alias oscars -storepass changeit -noprompt -file oscars.pem -keystore nsi-trust.jks
	$ keytool -import -alias surfnetbod -storepass changeit -noprompt -file surfnetbod.pem -keystore nsi-trust.jks
	$ keytool -import -alias netherlight -storepass changeit -noprompt -file netherlight.pem -keystore nsi-trust.jks
	$ keytool -import -alias singaren -storepass changeit -noprompt -file singaren.pem -keystore nsi-trust.jks
	$ keytool -import -alias manlan -storepass changeit -noprompt -file manlan.pem -keystore nsi-trust.jks
	$ keytool -import -alias uvalight -storepass changeit -noprompt -file uvalight.pem -keystore nsi-trust.jks
	証明書がキーストアに追加されました

	$ keytool -list -v -storepass changeit -keystore nsi-trust.jks
	・・・

	これで、nsi-trust.jks に、公式証明書＋norduオレオレ証明書が入る。
	
特定のキーの削除
	keytool -delete -alias uvalight -storepass changeit -keystore nsi-trust.jks


実行時の指定(一般)
	java -Djavax.net.ssl.trustStore=nsi-trust.jks -Djavax.net.ssl.trustStorePassword=changeit ....

NSI2実装での証明書指定
	nsi2/java/common/etc/nsi2.properties
		ssl.trustStore=/home/demo/nsi2/java/common/etc/nsi-trust.jks
		ssl.trustStorePassword=changeit
	を指定して ant。

	NSIProperties クラスの初回読み込み時に、
		System.setProperty("javax.net.ssl.trustStore", sslTrust);
		System.setProperty("javax.net.ssl.trustStorePassword", sslPass);
	する。
