package net.glambda.nsi2.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.xml.ws.BindingProvider;

// import net.glambda.nsi2.impl.FixedWrapperClassInInterceptor;
import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.impl.ProviderPortReconnectAlways;
import net.glambda.nsi2.util.HTTPAuthProperties.BasicAuth;

import org.apache.commons.logging.Log;
// import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
// import org.apache.cxf.interceptor.Interceptor;
// import org.apache.cxf.jaxws.support.JaxWsEndpointImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionServiceProvider;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionServiceRequester;

public class NSIUtil {

    private static final NSIProperties nsiProp = NSIProperties.getInstance();
    protected static final Log logger = AbstractLog.getLog(NSIUtil.class);

    public static void setReceiveTimeout(Object port) {
        org.apache.cxf.endpoint.Client client;
        try {
            client = ClientProxy.getClient(port);
        } catch (Exception e) {
            logger.warn("cannot get org.apache.cxf.endpoint.Client", e);
            return;
        }
        if (client == null) {
            logger.warn("ClientProxy.getClient() retuns null: port=" + port.getClass().getName());
            return;
        }
        HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
        HTTPClientPolicy policy = httpConduit.getClient();
        long t0;
        if (policy == null) {
            policy = new HTTPClientPolicy();
            httpConduit.setClient(policy);
            t0 = -1;
        } else {
            t0 = policy.getReceiveTimeout();
        }
        policy.setReceiveTimeout(1000L * nsiProp.replyTimeoutSec());
        long t1 = httpConduit.getClient().getReceiveTimeout();
        logger.info("setReceiveTimeout: default=" + t0 + ", changed to " + t1 + "[msec]");
    }

    private static void setAuthParams(URL url, BindingProvider binding) {
        String host = url.getHost();
        BasicAuth auth = HTTPAuthProperties.getHTTPBasicAuth(host);
        if (auth != null) {
            logger.info("set HTTP BASIC Auth for " + host + ", user=" + auth.username() + ", pass="
                    + auth.password());
            // add "Authorization" = "Basic xxxxxxx" header
            setUserPass(binding, auth.username(), auth.password());
        }
        String token = HTTPAuthProperties.getOAuth2Token(host);
        if (token != null) {
            logger.info("set HTTP OAuth2 token for " + host + ", token=" + token);
            // add "Authorization" = "bearer xxxxxxx" header
            setOAuth2Token(binding, token);
        }
    }

    public static ConnectionProviderPort getRawProviderPort(String uri) {
        ConnectionServiceProvider service = new ConnectionServiceProvider();
        ConnectionProviderPort port = service.getConnectionServiceProviderPort();
        BindingProvider binding = (BindingProvider) port;
        binding.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);

        // see https://access.redhat.com/discussions/1344833
        // Client client = ClientProxy.getClient(port);
        // JaxWsEndpointImpl jaxwsEndpoint = (JaxWsEndpointImpl)
        // client.getEndpoint();
        // List<Interceptor<? extends Message>> interceptors =
        // jaxwsEndpoint.getInInterceptors();
        // for (int i = 0; i < interceptors.size(); i++) {
        // if (interceptors.get(i) instanceof
        // org.apache.cxf.jaxws.interceptors.WrapperClassInInterceptor) {
        // logger.info("Replacing CXF WrapperClassInInterceptor by Custom FixedWrapperClassInInterceptor.");
        // interceptors.set(i, new FixedWrapperClassInInterceptor());
        // }
        // }

        return port;
    }

    public static ConnectionProviderPort getProviderPort(String uri) {
        URL url;
        try {
            url = new URL(uri);
        } catch (MalformedURLException e) {
            logger.warn(e);
            return null;
        }
        String reconnectHost = nsiProp.getProperty("nsi.reconnectalways.host");
        if (url.getHost().equals(reconnectHost)) {
            return new ProviderPortReconnectAlways(uri);
        } else {
            ConnectionProviderPort port = getRawProviderPort(uri);
            SecurityUtil.initClientTLS(port);
            // setReceiveTimeout(port);
            setAuthParams(url, (BindingProvider) port);
            return port;
        }
    }

    public static ConnectionRequesterPort getRequesterPort(String uri) {
        URL url;
        try {
            url = new URL(uri);
        } catch (MalformedURLException e) {
            logger.warn(e);
            return null;
        }
        ConnectionServiceRequester service = new ConnectionServiceRequester();
        ConnectionRequesterPort port = service.getConnectionServiceRequesterPort();
        BindingProvider binding = (BindingProvider) port;
        binding.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);
        SecurityUtil.initClientTLS(port);
        // setReceiveTimeout(port);
        setAuthParams(url, binding);
        return port;
    }

    public static void setUserPass(BindingProvider bp, String user, String pass) {
        if (user != null) {
            bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, user);
        }
        if (pass != null) {
            bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, pass);
        }
    }

    public static void setOAuth2Token(BindingProvider bp, String token) {
        // http://cxf.apache.org/docs/interceptors.html
        // http://singztechmusings.wordpress.com/2011/09/17/apache-cxf-how-to-add-custom-http-headers-to-a-web-service-request/
        // http://tools.ietf.org/html/rfc6749#section-7
        if (token != null) {
            HashMap<String, List<String>> headers = new HashMap<String, List<String>>();
            headers.put("Authorization", Arrays.asList("bearer " + token));
            bp.getRequestContext().put(Message.PROTOCOL_HEADERS, headers);
        }
    }

    public static ConnectionProviderPort getProviderPort(String uri, String user, String pass) {
        ConnectionProviderPort port = getProviderPort(uri);
        setUserPass((BindingProvider) port, user, pass);
        return port;
    }

    public static ConnectionRequesterPort getRequesterPort(String uri, String user, String pass) {
        ConnectionRequesterPort port = getRequesterPort(uri);
        setUserPass((BindingProvider) port, user, pass);
        return port;
    }

    // /////////////////////////////////////////////////////////////////////////

    private static int id = 0;
    private static boolean B_DEBUG_ID = false;

    public static synchronized String getId(String key) {
        String v;
        if (B_DEBUG_ID) {
            v = key + "-" + id;
            id++;
        } else {
            // see uuidType in schema/nsi/ogf_nsi_connection_types_v1_0.xsd
            v = "urn:uuid:" + UUID.randomUUID().toString();
        }
        return v;
    }

    public static String getNewConnectionID() {
        return getId("ConnectionID");
    }

    public static String getNewCorrelationId() {
        return getId("CorrelationId");
    }

    public static String getNewGlobalId() {
        return getId("GlobalId");
    }

    public static String getProviderProtocolVersion() {
        // https://www.ogf.org/documents/GFD.212.pdf , Table 6
        return "application/vnd.ogf.nsi.cs.v2.provider+soap";
    }

    public static String getRequesterProtocolVersion() {
        return "application/vnd.ogf.nsi.cs.v2.requester+soap";
    }

    public static final String NSI_PREFIX = "urn:ogf:network:";

    public static String dropPrefix(String txt) {
        if (txt != null && txt.startsWith(NSI_PREFIX)) {
            return txt.substring(NSI_PREFIX.length());
        } else {
            return txt;
        }
    }

    public static String dropStpExt(String txt) {
        if (txt != null) {
            int i = txt.lastIndexOf('?');
            if (i > 0) {
                return txt.substring(0, i);
            }
        }
        return txt;
    }

    public static String dropPrefixStpExt(String txt) {
        return dropStpExt(dropPrefix(txt));
    }

    public static String appendPrefix(String txt) {
        if (txt != null && !txt.startsWith(NSI_PREFIX)) {
            return NSI_PREFIX + txt;
        } else {
            return txt;
        }
    }

}
