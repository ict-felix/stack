/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.requester.ReserveOpe;
import net.glambda.nsi2.util.NSITextDump;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class QueryOpe extends OpeBase {

    public final static String OPT_OPERATION = "o";
    public final static String OPT_SYNC = "s";
    public final static String OPT_ALL = "a";
    public final static String OPT_REQUESTER = "R";

    private static final NSIProperties nsiProp = NSIProperties.getInstance();

    @Override
    protected void addOptions(Options options) {
        OptionBuilder.hasOptionalArgs();
        OptionBuilder.withValueSeparator(',');
        OptionBuilder.withArgName("connId[,...]");
        OptionBuilder.withDescription("ConnectionID Index (printed before reseve), or UUID");
        options.addOption(OptionBuilder.create(OPT_CONNID));

        OptionBuilder.hasOptionalArgs();
        OptionBuilder.withValueSeparator(',');
        OptionBuilder.withArgName("globalId[,...]");
        OptionBuilder.withDescription("GlobalReservationID");
        options.addOption(OptionBuilder.create(ReserveOpe.OPT_GLOBALID));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("operation");
        OptionBuilder.withDescription("Operation Type [s: Summary (default), r: Recursive]");
        options.addOption(OptionBuilder.create(OPT_OPERATION));

        OptionBuilder.hasArgs(0);
        OptionBuilder.withDescription("Call Sync operation if set (default: not set, async)");
        options.addOption(OptionBuilder.create(OPT_SYNC));

        OptionBuilder.hasArgs(0);
        OptionBuilder.withDescription("query all requester's reservations (set requesterNSA "
                + nsiProp.getQueryAllNSA() + ")");
        options.addOption(OptionBuilder.create(OPT_ALL));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("requesterNSA");
        OptionBuilder.withDescription("set specified requesterNSA");
        options.addOption(OptionBuilder.create(OPT_REQUESTER));
    }

    private QueryType makeQueryType(CommandLine cmd) throws Exception {
        QueryType filter = new QueryType();
        String[] ids = cmd.getOptionValues("c");
        if (ids != null) {
            for (String id : ids) {
                String cid = getConnectionID(id);
                filter.getConnectionId().add(cid);
            }
        }
        ids = cmd.getOptionValues("g");
        if (ids != null) {
            for (String id : ids) {
                filter.getGlobalReservationId().add(id);
            }
        }
        return filter;
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        QueryType queryType = makeQueryType(cmd);
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        String reqNSA = cmd.getOptionValue(OPT_REQUESTER);
        if (reqNSA != null) {
            header.setRequesterNSA(reqNSA);
        }
        if (cmd.hasOption(OPT_ALL)) {
            header.setRequesterNSA(nsiProp.getQueryAllNSA());
        }

        boolean bRecursive = ("r".equals(cmd.getOptionValue(OPT_OPERATION)));
        boolean bSync = cmd.hasOption(OPT_SYNC);
        log(cmd,
                String.format("**** query request [recursive:%s, sync:%s] ****",
                        Boolean.toString(bRecursive), Boolean.toString(bSync)));
        log(cmd, NSITextDump.toString(header, queryType));
        if (!bRecursive) {
            if (bSync) {
                try {
                    QuerySummaryConfirmedType summary = port.querySummarySync(queryType);
                    log(cmd, NSITextDump.toString(header, summary));
                } catch (Error e) {
                    logger.warn(e);
                }
            } else {
                port.querySummary(queryType);
            }
        } else {
            if (!bSync) {
                port.queryRecursive(queryType);
            } else {
                throw new Exception("queryRecursive only supports async mode, drop -" + OPT_SYNC
                        + " option");
            }
        }
    }
}
