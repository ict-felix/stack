/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.util.LinkedList;

import javax.xml.ws.Holder;

import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.topology.DopnPathFinderUtil;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.pathfinder.PathFindingResult;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class PathFinderReserve extends ReserveOpe {

    private final PathFindOpe findOpe;

    public PathFinderReserve(PathFindOpe findOpe) {
        this.findOpe = findOpe;
    }

    @Override
    protected void addOptions(Options options) {
        addScheduleOption(options);
        addServiceTypeOption(options);
        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("version");
        OptionBuilder.withDescription("new version of the reservation (default: "
                + NSIConstants.INITIAL_VERSION + ", \"null\" to set null");
        options.addOption(OptionBuilder.create(OPT_VERSION));
    }

    private void reserve(ConnectionProviderPort provider, CommandLine cmd,
            String globalReservationId, String description, ReservationRequestCriteriaType criteria)
            throws Exception {
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);

        Holder<String> holder = new Holder<String>();
        String connectionId = holder.value = null;

        log(cmd, "**** reservation request ****");
        log(cmd, NSITextDump.toString(header, globalReservationId, description, connectionId,
                criteria));
        port.reserve(holder, globalReservationId, description, criteria);
        connectionId = holder.value;
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        PathFindingResult result = findOpe.getLastResult();
        if (result == null) {
            throw new Exception("do \"pathfind\" first!");
        }
        String globalReservationId = cmd.getOptionValue(OPT_GLOBALID, null);
        String description = cmd.getOptionValue(OPT_DESCRIPTION, null);
        ReservationRequestCriteriaType baseCriteria = makeCriteria(cmd);
        LinkedList<ReservationRequestCriteriaType> list =
                DopnPathFinderUtil.makeCriteriaList(baseCriteria, result);
        for (ReservationRequestCriteriaType criteria : list) {
            try {
                reserve(provider, cmd, globalReservationId, description, criteria);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

}
