/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.logging.Log;

import net.glambda.nsi2.converter.ToRMS;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.rms.DataPlaneState;
import net.glambda.rms.EthernetResourceManager;
import net.glambda.rms.LambdaResourceManager;
import net.glambda.rms.NSI2ResourceManagerBase;
import net.glambda.rms.Notifier;
import net.glambda.rms.ODUResourceManager;
import net.glambda.rms.TransferResourceManager;
import net.glambda.rms.types.CommonHeaderType;
import net.glambda.rms.types.CriteriaBase;
import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.LambdaCriteria;
import net.glambda.rms.types.ODUCriteria;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.TransferCriteria;

// NOTE: just for test & debug
public class SampleResourceManager implements NSI2ResourceManagerBase, EthernetResourceManager,
        ODUResourceManager, LambdaResourceManager, TransferResourceManager {

    protected static final Log logger = AbstractLog.getLog(SampleResourceManager.class);

    private class RMSTimerTask extends TimerTask {

        private final String connectionId;
        private final boolean bStartTimer;

        RMSTimerTask(String connectionId, boolean bStartTimer) {
            this.connectionId = connectionId;
            this.bStartTimer = bStartTimer;
        }

        @Override
        public void run() {
            logger.info("start TimerTask: connId=" + connectionId);
            try {
                if (bStartTimer) {
                    if (isProvisioned) {
                        notifier.dataPlaneStateChange(connectionId, DataPlaneState.ACTIVE);
                    }
                } else {
                    if (isProvisioned) {
                        notifier.dataPlaneStateChange(connectionId, DataPlaneState.INACTIVE);
                    }
                    notifier.dataPlaneStateChange(connectionId, DataPlaneState.PASSED_END_TIME);
                }
            } catch (Exception e) {
                logger.warn(e);
            }
            logger.info("end TimerTask: connId=" + connectionId);
        }

    }

    private static final int RESERVE_TIMEOUT = NSIProperties.getInstance().reserveTimeoutSec();

    private class ReserveTimeoutTask extends TimerTask {

        private final String connectionId;
        private final int version;

        ReserveTimeoutTask(String connectionId, int version) {
            this.connectionId = connectionId;
            this.version = version;
        }

        @Override
        public void run() {
            try {
                logger.warn("connId=" + connectionId + ", version=" + version + " has timeouted!");
                notifier.reserveTimeout(connectionId, RESERVE_TIMEOUT);
            } catch (Exception e) {
                logger.warn(e);
            }
            cancel();
        }

    }

    private static final Timer timer = new Timer();

    private class Resource {
        private final String connectionId;
        private Calendar start;
        private RMSTimerTask startTimer;
        private RMSTimerTask endTimer;
        private ReserveTimeoutTask reserveTimer = null;

        Resource(String connectionId, Calendar start, Calendar end) {
            this.connectionId = connectionId;
            setTimer(start, end);
        }

        private synchronized void setTimer(Calendar start, Calendar end) {
            if (start != null) {
                this.start = start;
            }
            if (start != null && Calendar.getInstance().before(start)) {
                this.startTimer = new RMSTimerTask(connectionId, true);
                timer.schedule(startTimer, start.getTime());
                logger.info(String.format(Locale.US, "set startTimer at  %tc, connId=%s",
                        start.getTime(), connectionId));
            } else {
                this.startTimer = null;
            }
            if (end != null) {
                this.endTimer = new RMSTimerTask(connectionId, false);
                timer.schedule(endTimer, end.getTime());
                logger.info(String.format(Locale.US, "set endTimer at  %tc, connId=%s",
                        start.getTime(), connectionId));
            } else {
                this.endTimer = null;
            }
        }

        private synchronized void cancelTimer() {
            if (startTimer != null) {
                startTimer.cancel();
                startTimer = null;
            }
            if (endTimer != null) {
                endTimer.cancel();
                endTimer = null;
            }
        }

        private synchronized void resetTimer(Calendar start, Calendar end) {
            if (start != null && startTimer != null) {
                startTimer.cancel();
                startTimer = null;
            }
            if (end != null && endTimer != null) {
                endTimer.cancel();
                endTimer = null;
            }
            setTimer(start, end);
        }

        private synchronized Calendar getStartTime() {
            return start;
        }

        private synchronized void cancelReserveTimeoutTimer() {
            if (reserveTimer != null) {
                reserveTimer.cancel();
                reserveTimer = null;
            }
        }

        private synchronized void setReserveTimeoutTimer(int version) {
            cancelReserveTimeoutTimer();
            reserveTimer = new ReserveTimeoutTask(connectionId, version);
            Calendar limit = Calendar.getInstance();
            limit.add(Calendar.SECOND, RESERVE_TIMEOUT);
            logger.info("set reserveTimeout timer: limit at "
                    + String.format(Locale.US, "%tc", limit) + ", connId=" + connectionId);
            timer.schedule(reserveTimer, limit.getTime());
        }

    }

    private static final HashMap<String, Resource> resourceMap = new HashMap<String, Resource>();
    private Notifier notifier;

    private boolean isProvisioned;

    @Override
    public void setNotifier(Notifier notifier) {
        this.notifier = notifier;
    }

    private void reserveBase(CommonHeaderType header, String connectionId,
            String globalReservationId, String description, CriteriaBase criteria)
            throws ServiceException {
        Resource r = new Resource(connectionId, criteria.getStartTime(), criteria.getEndTime());
        resourceMap.put(connectionId, r);
        r.setReserveTimeoutTimer(criteria.getVersion());
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, EthernetCriteria criteria) throws ServiceException {
        reserveBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, ODUCriteria criteria) throws ServiceException {
        reserveBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, LambdaCriteria criteria) throws ServiceException {
        reserveBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, TransferCriteria criteria) throws ServiceException {
        reserveBase(header, connectionId, globalReservationId, description, criteria);
    }

    private Resource getResource(String connectionId) throws ServiceException {
        Resource r = resourceMap.get(connectionId);
        if (r != null) {
            return r;
        } else {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(
                    ErrorID.CONNECTION_NONEXISTENT, connectionId));
        }
    }

    private void modifyBase(CommonHeaderType header, String connectionId,
            String globalReservationId, String description, CriteriaBase criteria)
            throws ServiceException {
        Resource r = getResource(connectionId);
        r.resetTimer(criteria.getStartTime(), criteria.getEndTime());
        r.setReserveTimeoutTimer(criteria.getVersion());
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, EthernetCriteria criteria) throws ServiceException {
        modifyBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, ODUCriteria criteria) throws ServiceException {
        modifyBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, LambdaCriteria criteria) throws ServiceException {
        modifyBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, TransferCriteria criteria) throws ServiceException {
        modifyBase(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void commit(CommonHeaderType header, String connectionId) throws ServiceException {
        Resource r = getResource(connectionId);
        r.cancelReserveTimeoutTimer();
    }

    @Override
    public void abort(CommonHeaderType header, String connectionId) throws ServiceException {
        Resource r = getResource(connectionId);
        r.cancelReserveTimeoutTimer();
    }

    @Override
    public void provision(CommonHeaderType header, String connectionId) throws ServiceException {
        Resource r = getResource(connectionId);
        isProvisioned = true;
        long now = Calendar.getInstance().getTimeInMillis();
        long start = r.getStartTime().getTimeInMillis();
        if (start <= now) {
            notifier.dataPlaneStateChange(connectionId, DataPlaneState.ACTIVE);
        }
    }

    @Override
    public void release(CommonHeaderType header, String connectionId) throws ServiceException {
        Resource r = getResource(connectionId);
        isProvisioned = false;
        long now = Calendar.getInstance().getTimeInMillis();
        long start = r.getStartTime().getTimeInMillis();
        if (start <= now) {
            notifier.dataPlaneStateChange(connectionId, DataPlaneState.INACTIVE);
        }
    }

    @Override
    public void terminate(CommonHeaderType header, String connectionId) throws ServiceException {
        // do nothing
        Resource r = getResource(connectionId);
        isProvisioned = false;
        r.cancelTimer();
        r.cancelReserveTimeoutTimer();
    }

}
