/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.logging.Log;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.topology.STP.STPType;
import net.glambda.nsi2.util.AbstractLog;
import nsidiscovery.protocol.*;
import nsidiscovery.nsa.*;
import nsitopology.BidirectionalPortType;
import nsitopology.LabelGroupType;
import nsitopology.NetworkObject;
import nsitopology.PortGroupRelationType;
import nsitopology.PortGroupType;
import nsitopology.TopologyRelationType;
import nsitopology.TopologyType;

public class TopologyLoader {

    protected static final Log logger = AbstractLog.getLog(TopologyLoader.class);
    private static Unmarshaller discoveryProtocolUnmarshaller, discoveryNsaUnmarshaller,
            topologyUnmarshaller;

    static {
        try {
            JAXBContext discoveryProtocolContext =
                    JAXBContext.newInstance(nsidiscovery.protocol.ObjectFactory.class.getPackage()
                            .getName());
            discoveryProtocolUnmarshaller = discoveryProtocolContext.createUnmarshaller();
            JAXBContext discoveryNsaContext =
                    JAXBContext.newInstance(nsidiscovery.nsa.ObjectFactory.class.getPackage()
                            .getName());
            discoveryNsaUnmarshaller = discoveryNsaContext.createUnmarshaller();
            JAXBContext topologyContext =
                    JAXBContext.newInstance(nsitopology.ObjectFactory.class.getPackage().getName());
            topologyUnmarshaller = topologyContext.createUnmarshaller();
        } catch (Exception e) {
            logger.fatal(e);
            System.exit(1);
        }
    }

    private static LinkedList<NSA> nsaList = null;

    private static CollectionType loadMasterDDS(String filename) throws Exception {
        logger.info("loading MasterDDS from " + filename);
        Object o;
        filename = filename.trim();
        URL url;
        try {
            url = new URL(filename);
            o = discoveryProtocolUnmarshaller.unmarshal(url);
        } catch (MalformedURLException e) {
            InputStream is = new FileInputStream(filename);
            o = discoveryProtocolUnmarshaller.unmarshal(is);
        }
        if (o instanceof JAXBElement) {
            JAXBElement<?> jaxbEle = (JAXBElement<?>) o;
            o = jaxbEle.getValue();
        } else {
            throw new Exception("invalid topology file: " + filename);
        }
        if (o instanceof CollectionType) {
            return (CollectionType) o;
        } else {
            throw new Exception("invalid object type: " + o.getClass().getSimpleName()
                    + " must be " + CollectionType.class.getSimpleName());
        }
    }

    private static class NSATopology {
        final NsaType nsa;
        final TopologyType topology;

        NSATopology(NsaType nsa, TopologyType topology) {
            this.nsa = nsa;
            this.topology = topology;
        }
    }

    private static Object getContent(DocumentType doc, Unmarshaller m) throws Exception {
        AnyType any = doc.getContent();
        if (any.getAny().size() != 1) {
            throw new Exception("document " + doc.getId() + " has " + any.getAny().size()
                    + " contents, must be 1");
        }
        Object o = any.getAny().get(0);
        if (!(o instanceof Node)) {
            throw new Exception("document " + doc.getId() + " has "
                    + o.getClass().getCanonicalName() + ", must be "
                    + Node.class.getCanonicalName());
        }
        Document xmlDoc = ((Node) o).getOwnerDocument();
        o = m.unmarshal(xmlDoc);
        if (o instanceof JAXBElement) {
            JAXBElement<?> jaxbEle = (JAXBElement<?>) o;
            return jaxbEle.getValue();
        } else {
            throw new Exception("document " + doc.getId() + " has "
                    + o.getClass().getCanonicalName() + ", must be "
                    + JAXBElement.class.getCanonicalName());
        }
    }

    private static NsaType getNsaType(DocumentType doc) throws Exception {
        Object o = getContent(doc, discoveryNsaUnmarshaller);
        if (o instanceof NsaType) {
            return (NsaType) o;
        } else {
            throw new Exception("document " + doc.getId() + " has invalid object type: "
                    + o.getClass().getSimpleName() + " must be " + NsaType.class.getSimpleName());
        }
    }

    private static boolean isPA(NsaType nsa) {
        for (FeatureType f : nsa.getFeature()) {
            if (TopologyConstants.TYPE_DDS_uPA.equals(f.getType())) {
                return true;
            }
        }
        return false;
    }

    private static boolean isAggregator(NsaType nsa) {
        for (FeatureType f : nsa.getFeature()) {
            if (TopologyConstants.TYPE_DDS_AGGREGATOR.equals(f.getType())) {
                return true;
            }
        }
        return false;
    }

    private static TopologyType getTopologyType(DocumentType doc) throws Exception {
        Object o = getContent(doc, topologyUnmarshaller);
        if (o instanceof TopologyType) {
            return (TopologyType) o;
        } else {
            throw new Exception("document " + doc.getId() + " has invalid object type: "
                    + o.getClass().getSimpleName() + " must be "
                    + TopologyType.class.getSimpleName());
        }
    }

    private static TreeMap<String, NSATopology> makeNsaTopologyMap(CollectionType collection)
            throws Exception {
        List<DocumentType> docList = collection.getDocuments().getDocument();
        if (docList.size() == 0) {
            throw new Exception("empty documents");
        }
        HashMap<String, NsaType> nsaMap = new HashMap<String, NsaType>();
        HashMap<String, TopologyType> topologyMap = new HashMap<String, TopologyType>();
        HashMap<String, String> topo2nsaMap = new HashMap<String, String>();
        for (DocumentType doc : docList) {
            try {
                if (TopologyConstants.TYPE_DDS_NSA.equals(doc.getType())) {
                    String id = doc.getNsa();
                    NsaType nsa = getNsaType(doc);
                    if (isPA(nsa)) {
                        nsaMap.put(id, nsa);
                    } else if (isAggregator(nsa)) {
                        nsaMap.put(id, nsa);
                        TopologyType topo = new TopologyType();
                        topo.setId(id);
                        topologyMap.put(id, topo);
                        topo2nsaMap.put(id, id);
                    }
                } else if (TopologyConstants.TYPE_DDS_TOPOLOGY.equals(doc.getType())) {
                    TopologyType topo = getTopologyType(doc);
                    topologyMap.put(topo.getId(), topo);
                    topo2nsaMap.put(topo.getId(), doc.getNsa());
                }
            } catch (Exception e) {
                logger.warn(e);
            }
        }
        TreeMap<String, NSATopology> nsaTopoMap = new TreeMap<String, NSATopology>();
        for (Entry<String, TopologyType> e : topologyMap.entrySet()) {
            String topoId = e.getKey();
            String nsaId = topo2nsaMap.get(topoId);
            NsaType nsa = nsaMap.get(nsaId);
            if (nsa != null) {
                nsaTopoMap.put(topoId, new NSATopology(nsa, e.getValue()));
            } else {
                logger.warn("cannot find NSA for topology id=" + topoId);
            }
        }
        return nsaTopoMap;
    }

    private static NSA nsaTopo2nsa(NsaType nsa, TopologyType topo) throws Exception {
        LinkedList<STP> inStps = new LinkedList<STP>();
        LinkedList<STP> outStps = new LinkedList<STP>();
        LinkedList<STP> biStps = new LinkedList<STP>();

        for (TopologyRelationType rel : topo.getRelation()) {
            String type = rel.getType();
            STPType stpType = null;
            if (type.equals(TopologyConstants.TYPE_IN_BOUND_PORT)) {
                stpType = STPType.IN;
            } else if (type.equals(TopologyConstants.TYPE_OUT_BOUND_PORT)) {
                stpType = STPType.OUT;
            } else {
                continue;
            }
            if (rel.getPortGroup().isEmpty()) {
                logger.error("Relation of type=\"" + type
                        + "\" is empty, must have PortGroup element(s)");
                continue;
            }
            for (PortGroupType pg : rel.getPortGroup()) {
                String stpName = pg.getId();
                String vlanid = null;
                if (pg.getLabelGroup().isEmpty()) {
                    logger.warn("PortGroup id=\"" + stpName + "\" may have LabelGroup labeltype=\""
                            + TopologyConstants.TYPE_VLAN + "\", but empty");
                }
                for (LabelGroupType label : pg.getLabelGroup()) {
                    if (label.getLabeltype().equals(TopologyConstants.TYPE_VLAN)) {
                        if (vlanid == null) {
                            vlanid = label.getValue();
                        } else {
                            logger.error("duplicate " + TopologyConstants.TYPE_VLAN
                                    + " in PortGroup:id=" + stpName);
                        }
                    } else {
                        logger.warn("unknown labeltype: \"" + label.getLabeltype()
                                + "\" used at PortGroup id=" + stpName + ", must be \""
                                + TopologyConstants.TYPE_VLAN + "\"");
                    }
                }
                String connectedTo = null;
                for (PortGroupRelationType pgrel : pg.getRelation()) {
                    if (pgrel.getType().equals(TopologyConstants.TYPE_IS_ALIAS)) {
                        for (PortGroupType connpg : pgrel.getPortGroup()) {
                            if (connectedTo == null) {
                                connectedTo = connpg.getId();
                            } else {
                                logger.error("duplicate " + TopologyConstants.TYPE_IS_ALIAS
                                        + " in PortGroup:id=" + stpName);
                            }
                        }
                    }
                }

                STP stp = new STP(stpName, vlanid, connectedTo, stpType);
                if (stpType == STPType.IN) {
                    inStps.add(stp);
                } else {
                    outStps.add(stp);
                }
            }
        }
        //
        for (NetworkObject no : topo.getGroup()) {
            if (!(no instanceof BidirectionalPortType)) {
                continue;
            }
            BidirectionalPortType bi = (BidirectionalPortType) no;
            LinkedList<String> portIds = new LinkedList<String>();
            for (JAXBElement<? extends NetworkObject> ele : bi.getRest()) {
                Object o = ele.getValue();
                if (!(o instanceof PortGroupType)) {
                    logger.error("BidirectionalPort has a " + o.getClass().getSimpleName()
                            + " element, must be " + PortGroupType.class.getSimpleName());
                    continue;
                }
                portIds.add(((PortGroupType) o).getId());
            }
            if (portIds.size() != 2) {
                logger.error("BidirectionalPort id=" + bi.getId() + " has " + portIds.size()
                        + " PortGroup, must be 2");
                continue;
            }
            STP stp = new STPGroup(bi.getId(), STPType.BI, portIds);
            biStps.add(stp);
        }
        //
        String csEndpoint = null;
        for (InterfaceType i : nsa.getInterface()) {
            if (TopologyConstants.TYPE_PROVIDER.equals(i.getType())) {
                csEndpoint = i.getHref().trim();
                break;
            }
        }
        //
        return new NSA(topo.getId(), nsa.getId(), csEndpoint, inStps, outStps, biStps);
    }

    private static LinkedList<NSA> makeNSATopologyList(CollectionType collection) throws Exception {
        TreeMap<String, NSATopology> map = makeNsaTopologyMap(collection);
        LinkedList<NSA> list = new LinkedList<NSA>();
        for (NSATopology nt : map.values()) {
            list.add(nsaTopo2nsa(nt.nsa, nt.topology));
        }
        return list;
    }

    private static LinkedList<NSA> loadAll(String masterDDSXml) {
        try {
            CollectionType collection = loadMasterDDS(masterDDSXml);
            return makeNSATopologyList(collection);
        } catch (Exception e) {
            logger.fatal(e);
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    public static LinkedList<NSA> loadAll() {
        if (nsaList == null) {
            nsaList = loadAll(NSIProperties.getInstance().getMasterDDSXml());
        }
        return nsaList;
    }

    public static void main(String[] args) {
        loadAll();
        for (NSA nsa : nsaList) {
            System.out.println(nsa);
        }
    }

}
