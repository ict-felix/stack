/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import net.glambda.pathfinder.IFTYPE;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType;

public class PathFinderUtil {

    protected static final Log logger = AbstractLog.getLog(PathFinderUtil.class);

    public static final String DOPN_PARAMS = "__DOPN_PARAMS__";

    public static TypeValuePairListType makeConstraints(net.glambda.pathfinder.STP srcSTP,
            net.glambda.pathfinder.STP destSTP) {
        TypeValuePairListType constraints = new TypeValuePairListType();
        TypeValuePairType pair = new TypeValuePairType();
        pair.setType(DOPN_PARAMS);
        if (srcSTP.ifType == IFTYPE.ODU) {
            pair.getValue().add(srcSTP.tsId);
            pair.getValue().add(destSTP.tsId);
            pair.getValue().add(Integer.toString(srcSTP.tsWidth));
            pair.getValue().add(Integer.toString(destSTP.tsWidth));
        } else {
            pair.getValue().add(srcSTP.lambdaId);
            pair.getValue().add(destSTP.lambdaId);
            pair.getValue().add(Integer.toString(srcSTP.lambdaWidth));
            pair.getValue().add(Integer.toString(destSTP.lambdaWidth));
        }
        constraints.getAttribute().add(pair);
        logger.info(pair.getType() + " = " + pair.getValue().toString());
        return constraints;
    }

    public static TypeValuePairType getDopnParams(TypeValuePairListType list) {
        if (list == null) {
            return null;
        }
        for (TypeValuePairType pair : list.getAttribute()) {
            if (pair.getType().equals(DOPN_PARAMS)) {
                logger.info(pair.getType() + " = " + pair.getValue().toString());
                return pair;
            }
        }
        return null;
    }

}
