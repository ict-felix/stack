/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

@javax.jws.WebService(portName = "ConnectionServiceRequesterPort", serviceName = "ConnectionServiceRequester", targetNamespace = "http://schemas.ogf.org/nsi/2013/12/connection/requester", endpointInterface = "org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort")
public class SampleRequesterWaitable extends SampleRequester {

    protected static final Log logger = AbstractLog.getLog(SampleRequester.class);

    private final HashMap<String, Object> replyMap = new HashMap<String, Object>();
    private final EventListener listener;

    public SampleRequesterWaitable(boolean bSysOutLog) {
        super(bSysOutLog);
        listener = null;
    }

    public SampleRequesterWaitable() {
        super();
        listener = null;
    }

    public SampleRequesterWaitable(EventListener listener) {
        super(false);
        this.listener = listener;
    }

    public Object waitReply(String corId, long waitMsec) {
        long deadline = System.currentTimeMillis() + waitMsec;
        logger.info("wait reply of correlationId=" + corId + " until "
                + String.format(Locale.US, "%tc", new Date(deadline)));
        synchronized (replyMap) {
            long now;
            while ((now = System.currentTimeMillis()) < deadline) {
                // NOTE: remove() returns null if not exists, or removed object
                Object o = replyMap.remove(corId);
                if (o != null) {
                    return o;
                }
                try {
                    replyMap.wait(deadline - now);
                } catch (InterruptedException e) {
                    logger.warn(e);
                    return null;
                }
            }
            return replyMap.remove(corId);
        }
    }

    public Object waitReply(String corId) {
        return waitReply(corId, 10 * 1000L);
    }

    protected void addReply(String corId, Object o) {
        logger.info("received reply of correlationId=" + corId);
        synchronized (replyMap) {
            replyMap.put(corId, o);
            replyMap.notifyAll();
        }
    }

    @Override
    public void reserveConfirmed(String connectionId, String globalReservationId,
            String description, ReservationConfirmCriteriaType criteria) throws ServiceException {
        CommonHeaderType header =
                reserveConfirmedHeader(connectionId, globalReservationId, description, criteria);
        addReply(header.getCorrelationId(), criteria);
    }

    public static class FailedMessage {
        private final ConnectionStatesType connectionStates;
        private final ServiceExceptionType serviceException;

        FailedMessage(ConnectionStatesType connectionStates, ServiceExceptionType serviceException) {
            this.connectionStates = connectionStates;
            this.serviceException = serviceException;
        }

        public ConnectionStatesType getConnectionStatesType() {
            return connectionStates;
        }

        public ServiceExceptionType getServiceExceptionType() {
            return serviceException;
        }

    }

    @Override
    public void reserveFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        CommonHeaderType header =
                genericFailedHeader("ReserveFailed", connectionId, connectionStates,
                        serviceException);
        addReply(header.getCorrelationId(), new FailedMessage(connectionStates, serviceException));
    }

    public static final String CONFIRMED = "CONFIRMED";

    @Override
    public void reserveCommitConfirmed(String connectionId) throws ServiceException {
        CommonHeaderType header = genericConfirmedHeader("reserveCommitConfirmed", connectionId);
        addReply(header.getCorrelationId(), CONFIRMED);
    }

    @Override
    public void reserveCommitFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        CommonHeaderType header =
                genericFailedHeader("reserveCommitFailed", connectionId, connectionStates,
                        serviceException);
        addReply(header.getCorrelationId(), new FailedMessage(connectionStates, serviceException));
    }

    @Override
    public void reserveAbortConfirmed(String connectionId) throws ServiceException {
        CommonHeaderType header = genericConfirmedHeader("reserveAbortConfirmed", connectionId);
        addReply(header.getCorrelationId(), CONFIRMED);
    }

    @Override
    public void provisionConfirmed(String connectionId) throws ServiceException {
        CommonHeaderType header = genericConfirmedHeader("provisionConfirmed", connectionId);
        addReply(header.getCorrelationId(), CONFIRMED);
    }

    @Override
    public void releaseConfirmed(String connectionId) throws ServiceException {
        CommonHeaderType header = genericConfirmedHeader("releaseConfirmed", connectionId);
        addReply(header.getCorrelationId(), CONFIRMED);
    }

    @Override
    public void terminateConfirmed(String connectionId) throws ServiceException {
        CommonHeaderType header = genericConfirmedHeader("terminateConfirmed", connectionId);
        addReply(header.getCorrelationId(), CONFIRMED);
    }

    @Override
    public void querySummaryConfirmed(List<QuerySummaryResultType> reservation)
            throws ServiceException {
        CommonHeaderType header = querySummaryConfirmedHeader(reservation);
        addReply(header.getCorrelationId(), reservation);
    }

    @Override
    public void queryRecursiveConfirmed(List<QueryRecursiveResultType> reservation)
            throws ServiceException {
        CommonHeaderType header = queryRecursiveConfirmedHeader(reservation);
        addReply(header.getCorrelationId(), reservation);
    }

    @Override
    public GenericAcknowledgmentType queryNotificationConfirmed(
            QueryNotificationConfirmedType queryNotificationConfirmed) throws ServiceException {
        CommonHeaderType header = queryNotificationConfirmedHeader(queryNotificationConfirmed);
        addReply(header.getCorrelationId(), queryNotificationConfirmed);
        return new GenericAcknowledgmentType();
    }

    @Override
    public void dataPlaneStateChange(String connectionId, long notificationId, Calendar timeStamp,
            DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        CommonHeaderType header =
                dataPlaneStateChangeHeader(connectionId, notificationId, timeStamp, dataPlaneStatus);
        if (listener != null) {
            listener.dataPlaneStateChange(header, connectionId, notificationId, timeStamp,
                    dataPlaneStatus);
        }
    }

    @Override
    public void errorEvent(String connectionId, long notificationId, Calendar timeStamp,
            EventEnumType event, String originatingConnectionId, String originatingNSA,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException)
            throws ServiceException {
        CommonHeaderType header =
                errorEventHeader(connectionId, notificationId, timeStamp, event, additionalInfo,
                        serviceException);
        if (listener != null) {
            listener.errorEvent(header, connectionId, notificationId, timeStamp, event,
                    originatingConnectionId, originatingNSA, additionalInfo, serviceException);
        }
    }

    @Override
    public void error(ServiceExceptionType serviceException) throws ServiceException {
        CommonHeaderType header = errorHeader(serviceException);
        if (listener != null) {
            listener.error(header, serviceException);
        }
    }
}
