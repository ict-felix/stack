/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueryLog {

    private static final Pattern START = Pattern
            .compile("([0-9]+):([0-9]+):([0-9]+)\\.([0-9]+) \\+0900 INFO  queryId +([^ ]+)");
    private static final Pattern END = Pattern
            .compile("([0-9]+):([0-9]+):([0-9]+)\\.([0-9]+) \\+0900 INFO  path finding result");

    private long m2msec(Matcher m) {
        long msec =
                3600 * Integer.parseInt(m.group(1)) + 60 * Integer.parseInt(m.group(2))
                        + Integer.parseInt(m.group(3));
        return 1000 * msec + Integer.parseInt(m.group(4));
    }

    private void parse(String filename) throws Exception {
        InputStream in = new FileInputStream(new File(filename));
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;
        long start = 0;
        String queryId = null;
        while ((line = br.readLine()) != null) {
            Matcher m = START.matcher(line);
            if (m.find()) {
                start = m2msec(m);
                queryId = m.group(5);
            } else {
                m = END.matcher(line);
                if (m.find()) {
                    long end = m2msec(m);
                    System.out.printf("%-15s %d\n", queryId, (end - start));
                }
            }
        }
        br.close();
    }

    public static void main(String[] args) throws Exception {
        QueryLog app = new QueryLog();
        app.parse("query.txt");
    }

}
