/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.converter;

import java.util.Calendar;

import org.apache.commons.logging.Log;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.pathfinder.IFTYPE;
import net.glambda.rms.types.CommonHeaderType;
import net.glambda.rms.types.CriteriaBase;
import net.glambda.rms.types.DirectionalityType;
import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.LambdaCriteria;
import net.glambda.rms.types.ODUCriteria;
import net.glambda.rms.types.OrderedStpType;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.ServiceExceptionType;
import net.glambda.rms.types.StpListType;
import net.glambda.rms.types.StpType;
import net.glambda.rms.types.TransferCriteria;
import net.glambda.rms.types.TransferRoleType;
import net.glambda.rms.types.TransferServiceType;
import net.glambda.rms.types.TypeValuePairListType;
import net.glambda.rms.types.TypeValuePairType;
import net.glambda.rms.types.VariablesType;
import net.glambda.schemas._2013._12.services.dopn.PathType;
import net.glambda.schemas._2013._12.services.dopn.SuperNetworkType;

public class ToRMS {

    protected static final Log logger = AbstractLog.getLog(ToRMS.class);

    public static CommonHeaderType convert(
            org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType header) {
        if (header == null) {
            return null;
        }
        CommonHeaderType result = new CommonHeaderType();
        result.setProtocolVersion(header.getProtocolVersion());
        result.setCorrelationId(header.getCorrelationId());
        result.setRequesterNSA(header.getRequesterNSA());
        result.setProviderNSA(header.getProviderNSA());
        result.setReplyTo(header.getReplyTo());
        // TODO
        // result.setSessionSecurityAttr(header.getSessionSecurityAttr());
        result.getAny().addAll(header.getAny());
        result.getOtherAttributes().putAll(header.getOtherAttributes());
        return result;
    }

    public static int convert(Integer v) {
        if (v != null) {
            return v;
        } else {
            return 0;
        }
    }

    public static int str2int(String s) {
        if (s != null) {
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                logger.warn("invalid number: " + s, e);
            }
        }
        return 0;
    }

    public static Calendar clone(Calendar cal) {
        if (cal != null) {
            return (Calendar) cal.clone();
        } else {
            return null;
        }
    }

    public static TypeValuePairType convert(
            org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType label) {
        if (label == null) {
            return null;
        }
        TypeValuePairType result = new TypeValuePairType();
        result.getValue().addAll(label.getValue());
        result.getAny().addAll(label.getAny());
        result.setType(label.getType());
        result.setNamespace(label.getNamespace());
        result.getOtherAttributes().putAll(label.getOtherAttributes());
        return result;
    }

    public static TypeValuePairListType convert(
            org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType labels) {
        if (labels == null) {
            return null;
        }
        TypeValuePairListType result = new TypeValuePairListType();
        for (org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType label : labels
                .getAttribute()) {
            result.getAttribute().add(convert(label));
        }
        return result;
    }

    public static VariablesType convert(
            org.ogf.schemas.nsi._2013._12.framework.types.VariablesType variables) {
        if (variables == null) {
            return null;
        }
        VariablesType result = new VariablesType();
        for (org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType label : variables
                .getVariable()) {
            result.getVariable().add(convert(label));
        }
        return result;
    }

    public static StpType convert(StpidVlan stpVlan) {
        if (stpVlan != null) {
            return TypesBuilder.makeStpType(stpVlan.stpid);
        } else {
            return null;
        }
    }

    public static StpType convert(String stpId) {
        if (stpId != null) {
            return convert(new StpidVlan(stpId));
        } else {
            return null;
        }
    }

    public static OrderedStpType convert(
            org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType ost) {
        if (ost == null) {
            return null;
        }
        OrderedStpType result = new OrderedStpType();
        result.setStp(convert(ost.getStp()));
        result.setOrder(ost.getOrder());
        return result;
    }

    public static StpListType convert(org.ogf.schemas.nsi._2013._12.services.types.StpListType ero) {
        if (ero == null) {
            return null;
        }
        StpListType result = new StpListType();
        for (org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType ost : ero.getOrderedSTP()) {
            result.getOrderedSTP().add(convert(ost));
        }
        return result;
    }

    private static DirectionalityType convert(
            org.ogf.schemas.nsi._2013._12.services.types.DirectionalityType directionality) {
        if (directionality == null) {
            return null;
        }
        return DirectionalityType.valueOf(directionality.name());
    }

    private static String convert(
            net.glambda.schemas._2013._12.services.dopn.SuperNetworkType superNetwokType) {
        if (superNetwokType == null) {
            return null;
        } else {
            return superNetwokType.value();
        }
    }

    private static String convert(net.glambda.schemas._2013._12.services.dopn.PathType pathType) {
        if (pathType == null) {
            return null;
        } else {
            return pathType.value();
        }
    }

    private static String convert(IFTYPE iftype) {
        if (iftype == null) {
            return null;
        } else {
            return iftype.name();
        }
    }

    private static EthernetCriteria makeEtherCriteria(
            org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType criteria,
            org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType p2p) {
        EthernetCriteria result = new EthernetCriteria();
        if (p2p.getCapacity() > 0) {
            result.setCapacity(p2p.getCapacity());
        }
        result.setDirectionality(convert(p2p.getDirectionality()));
        result.setSymmetricPath(p2p.isSymmetricPath());
        StpidVlan src = new StpidVlan(p2p.getSourceSTP());
        result.setSourceSTP(convert(src));
        result.setSourceVLAN(src.vlan);
        StpidVlan dest = new StpidVlan(p2p.getDestSTP());
        result.setDestSTP(convert(dest));
        result.setDestVLAN(dest.vlan);
        result.setEro(convert(p2p.getEro()));
        result.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return result;
    }

    private static int convertPathOrder(PathType pathType, Integer pathOrder) {
        if (pathType != null) {
            switch (pathType) {
            case PSRC:
            case PDST:
                return -1;
            default:
                break;
            }
        }
        if (pathOrder != null) {
            return (int) pathOrder;
        } else {
            return -1;
        }
    }

    private static ODUCriteria makeODUCriteria(
            org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType criteria,
            net.glambda.schemas._2013._12.services.dopn.ODUType odu) {
        ODUCriteria result = new ODUCriteria();
        result.setStartTime(criteria.getSchedule().getStartTime());
        result.setEndTime(criteria.getSchedule().getEndTime());
        result.setVersion(convert(criteria.getVersion()));
        //
        result.setSourceSTP(convert(odu.getSourceSTP()));
        result.setDestSTP(convert(odu.getDestSTP()));
        result.setSuperNetworkType(convert(SuperNetworkType.ODU));
        result.setPathType(convert(odu.getPathType()));
        result.setPathOrder(convertPathOrder(odu.getPathType(), odu.getPathOrder()));
        //
        result.setSourceIfType(convert(IFTYPE.ODU));
        result.setDestIfType(convert(IFTYPE.ODU));
        result.setSourceTsId(str2int(odu.getSourceTsId()));
        result.setDestTsId(str2int(odu.getDestTsId()));
        result.setSourceTsWidth(odu.getTsWidth());
        result.setDestTsWidth(odu.getTsWidth());
        return result;
    }

    private static LambdaCriteria makeLambdaCriteria(
            org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType criteria,
            net.glambda.schemas._2013._12.services.dopn.LambdaType lambda) {
        LambdaCriteria result = new LambdaCriteria();
        result.setStartTime(criteria.getSchedule().getStartTime());
        result.setEndTime(criteria.getSchedule().getEndTime());
        result.setVersion(convert(criteria.getVersion()));
        //
        result.setSourceSTP(convert(lambda.getSourceSTP()));
        result.setDestSTP(convert(lambda.getDestSTP()));
        result.setSuperNetworkType(convert(SuperNetworkType.LAMBDA));
        result.setProtection(lambda.isIsProtection());
        result.setSecondarySourceSTP(convert(lambda.getSecondarySourceSTP()));
        result.setSecondaryDestSTP(convert(lambda.getSecondaryDestSTP()));
        result.setPathType(convert(lambda.getPathType()));
        result.setPathOrder(convertPathOrder(lambda.getPathType(), lambda.getPathOrder()));
        //
        result.setSourceIfType(convert(IFTYPE.LAMBDA));
        result.setDestIfType(convert(IFTYPE.LAMBDA));
        result.setSourceLambdaId(str2int(lambda.getSourceLambdaId()));
        result.setDestLambdaId(str2int(lambda.getDestLambdaId()));
        result.setSourceLambdaWidth(lambda.getLambdaWidth());
        result.setDestLambdaWidth(lambda.getLambdaWidth());
        return result;
    }

    private static TransferServiceType convert(
            net.glambda.schemas._2013._12.services.dopn.TransferServiceType value) {
        if (value != null) {
            return TransferServiceType.fromValue(value.value());
        } else {
            return null;
        }
    }

    private static TransferRoleType convert(
            net.glambda.schemas._2013._12.services.dopn.TransferRoleType value) {
        if (value != null) {
            return TransferRoleType.fromValue(value.value());
        } else {
            return null;
        }
    }

    private static TransferCriteria makeTransferCriteria(
            org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType criteria,
            net.glambda.schemas._2013._12.services.dopn.TransferType transfer) {
        TransferCriteria result = new TransferCriteria();
        result.setStartTime(criteria.getSchedule().getStartTime());
        result.setEndTime(criteria.getSchedule().getEndTime());
        result.setVersion(convert(criteria.getVersion()));
        //
        result.setSourceSTP(transfer.getSourceSTP());
        result.setDestSTP(transfer.getDestSTP());
        result.setSourceIPAddress(transfer.getSourceIPAddress());
        result.setDestIPAddress(transfer.getDestIPAddress());
        result.setCapacity(transfer.getCapacity());
        result.setContentId(transfer.getContentId());
        result.setService(convert(transfer.getService()));
        result.setRole(convert(transfer.getRole()));
        result.setCacheEndTime(transfer.getCacheEndTime());
        return result;
    }

    public static CriteriaBase convert(
            org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType criteria)
            throws ServiceException {
        if (criteria.getAny().isEmpty()) {
            return null;
        }
        Object ele = TypesBuilder.getJAXBValue(criteria.getAny().get(0));
        CriteriaBase result = null;
        //
        if (ele instanceof org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType) {
            result =
                    makeEtherCriteria(
                            criteria,
                            (org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType) ele);
        } else if (ele instanceof Long) {
            Long capacity = (Long) ele;
            if (capacity > 0) {
                EthernetCriteria ether = new EthernetCriteria();
                ether.setCapacity(capacity);
                result = ether;
            }
        } else if (ele instanceof net.glambda.schemas._2013._12.services.dopn.ODUType) {
            result =
                    makeODUCriteria(criteria,
                            (net.glambda.schemas._2013._12.services.dopn.ODUType) ele);
        } else if (ele instanceof net.glambda.schemas._2013._12.services.dopn.LambdaType) {
            result =
                    makeLambdaCriteria(criteria,
                            (net.glambda.schemas._2013._12.services.dopn.LambdaType) ele);
        } else if (ele instanceof net.glambda.schemas._2013._12.services.dopn.TransferType) {
            result =
                    makeTransferCriteria(criteria,
                            (net.glambda.schemas._2013._12.services.dopn.TransferType) ele);
        }

        if (criteria.getSchedule() != null) {
            result.setStartTime(criteria.getSchedule().getStartTime());
            result.setEndTime(criteria.getSchedule().getEndTime());
        }
        result.setVersion(criteria.getVersion());

        logger.info(NSITextDump.addTab(NSITextDump.toString(result), "RMS:"
                + result.getClass().getSimpleName(), false));

        return result;
    }

    public static ServiceExceptionType convert(
            org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType e) {
        if (e == null) {
            return null;
        }
        ServiceExceptionType ex = new ServiceExceptionType();
        ex.setNsaId(e.getNsaId());
        ex.setConnectionId(e.getConnectionId());
        ex.setServiceType(e.getServiceType());
        ex.setErrorId(e.getErrorId());
        ex.setText(e.getText());
        ex.setVariables(convert(e.getVariables()));
        return ex;
    }

    public static ServiceException convert(
            org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException e) {
        return new ServiceException(e.getMessage(), convert(e.getFaultInfo()));
    }

}
