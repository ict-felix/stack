/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package net.glambda.nsi2.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.databinding.DataBinding;
import org.apache.cxf.databinding.WrapperCapableDatabinding;
import org.apache.cxf.databinding.WrapperHelper;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.service.Service;
import org.apache.cxf.service.model.BindingMessageInfo;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.service.model.MessageInfo;
import org.apache.cxf.service.model.MessagePartInfo;
import org.apache.cxf.service.model.OperationInfo;
import org.apache.cxf.service.model.ServiceModelUtil;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveResponseType;

public class FixedWrapperClassInInterceptor extends AbstractPhaseInterceptor<Message> {

    protected static final Log logger = LogFactory.getLog(FixedWrapperClassInInterceptor.class);

    // CXF 2.7.10 org.apache.cxf.service.factory.ReflectionServiceFactoryBean
    // CXF 3.1.0
    // org.apache.cxf.wsdl.service.factory.ReflectionServiceFactoryBean
    private static final String REF_HEADER = "messagepart.isheader";

    public FixedWrapperClassInInterceptor() {
        super(Phase.POST_LOGICAL);
    }

    public void handleMessage(Message message) throws Fault {
        Exchange ex = message.getExchange();
        BindingOperationInfo boi = ex.getBindingOperationInfo();
        if (Boolean.TRUE.equals(message.get(Message.PARTIAL_RESPONSE_MESSAGE)) || boi == null) {
            return;
        }

        Method method = ex.get(Method.class);

        if (method != null && method.getName().endsWith("Async")) {
            Class<?> retType = method.getReturnType();
            if (retType.getName().equals("java.util.concurrent.Future")
                    || retType.getName().equals("javax.xml.ws.Response")) {
                return;
            }
        }

        if (boi.isUnwrappedCapable()) {
            BindingOperationInfo boi2 = boi.getUnwrappedOperation();
            OperationInfo op = boi2.getOperationInfo();
            BindingMessageInfo bmi;

            MessageInfo wrappedMessageInfo = message.get(MessageInfo.class);
            MessageInfo messageInfo;
            if (wrappedMessageInfo == boi.getOperationInfo().getInput()) {
                messageInfo = op.getInput();
                bmi = boi2.getInput();
            } else {
                messageInfo = op.getOutput();
                bmi = boi2.getOutput();
            }

            // Sometimes, an operation can be unwrapped according to
            // WSDLServiceFactory,
            // but not according to JAX-WS. We should unify these at some point,
            // but
            // for now check for the wrapper class.
            MessageContentsList lst = MessageContentsList.getContentsList(message);
            if (lst == null) {
                return;
            }
            message.put(MessageInfo.class, messageInfo);
            message.put(BindingMessageInfo.class, bmi);
            ex.put(BindingOperationInfo.class, boi2);
            ex.put(OperationInfo.class, op);

            if (isGET(message)) {
                return;
            }

            MessagePartInfo wrapperPart = wrappedMessageInfo.getMessagePart(0);
            Class<?> wrapperClass = wrapperPart.getTypeClass();
            Object wrappedObject = lst.get(wrapperPart.getIndex());
            if (wrapperClass != null && !wrapperClass.isInstance(wrappedObject)) {
                wrappedObject = null;
                wrapperPart = null;
                wrapperClass = null;
            }
            if (wrapperClass == null || wrappedObject == null) {
                return;
            }

            WrapperHelper helper = wrapperPart.getProperty("WRAPPER_CLASS", WrapperHelper.class);
            if (helper == null) {
                Service service = ServiceModelUtil.getService(message.getExchange());
                DataBinding dataBinding = service.getDataBinding();
                if (dataBinding instanceof WrapperCapableDatabinding) {
                    helper =
                            createWrapperHelper((WrapperCapableDatabinding) dataBinding,
                                    messageInfo, wrappedMessageInfo, wrapperClass);
                    wrapperPart.setProperty("WRAPPER_CLASS", helper);
                } else {
                    return;
                }
            }

            MessageContentsList newParams;
            try {
                newParams = new MessageContentsList(helper.getWrapperParts(wrappedObject));
                // NOTE: set connectionId if not exists
                boolean isReserveRes = (wrappedObject instanceof ReserveResponseType);
                if (isReserveRes) {
                    ReserveResponseType res = (ReserveResponseType) wrappedObject;
                    if (newParams.size() >= 2 && newParams.get(1) == null) {
                        logger.info("set connId=" + res.getConnectionId());
                        newParams.set(1, res.getConnectionId());
                    }
                }

                List<Integer> removes = null;
                int count = 0;
                for (MessagePartInfo part : messageInfo.getMessageParts()) {
                    if (Boolean.TRUE.equals(part.getProperty(REF_HEADER))) {
                        MessagePartInfo mpi = wrappedMessageInfo.getMessagePart(part.getName());
                        if (mpi != null && lst.hasValue(mpi)) {
                            count++;
                            newParams.put(part, lst.get(mpi));
                        } else if (!isReserveRes && (mpi == null || mpi.getTypeClass() == null)) {
                            // NOTE: skip this if the message is ReserveResponse
                            // header, but not mapped to a param on the method
                            if (removes == null) {
                                removes = new ArrayList<Integer>();
                            }
                            removes.add(part.getIndex());
                        }
                    } else {
                        ++count;
                    }
                }
                if (count == 0) {
                    newParams.clear();
                } else if (removes != null) {
                    Collections.sort(removes, Collections.reverseOrder());
                    for (Integer i : removes) {
                        if (i < newParams.size()) {
                            newParams.remove(i.intValue());
                        }
                    }
                }

            } catch (Exception e) {
                throw new Fault(e);
            }

            message.setContent(List.class, newParams);
        }
    }

    private WrapperHelper createWrapperHelper(WrapperCapableDatabinding dataBinding,
            MessageInfo messageInfo, MessageInfo wrappedMessageInfo, Class<?> wrapperClass) {
        List<String> partNames = new ArrayList<String>();
        List<String> elTypeNames = new ArrayList<String>();
        List<Class<?>> partClasses = new ArrayList<Class<?>>();
        QName wrapperName = null;
        for (MessagePartInfo p : wrappedMessageInfo.getMessageParts()) {
            if (wrapperClass == p.getTypeClass()) {
                wrapperName = p.getElementQName();
            }
        }

        for (MessagePartInfo p : messageInfo.getMessageParts()) {
            if (Boolean.TRUE.equals(p.getProperty(REF_HEADER))) {
                if (p.getTypeClass() != null) {
                    int idx = p.getIndex();
                    ensureSize(elTypeNames, idx);
                    ensureSize(partClasses, idx);
                    ensureSize(partNames, idx);
                    elTypeNames.set(idx, null);
                    partClasses.set(idx, null);
                    partNames.set(idx, null);
                }
            } else {
                String elementType = null;
                if (p.getTypeQName() == null) {
                    // handling anonymous complex type
                    elementType = null;
                } else {
                    elementType = p.getTypeQName().getLocalPart();
                }
                int idx = p.getIndex();
                ensureSize(elTypeNames, idx);
                ensureSize(partClasses, idx);
                ensureSize(partNames, idx);

                elTypeNames.set(idx, elementType);
                partClasses.set(idx, p.getTypeClass());
                partNames.set(idx, p.getName().getLocalPart());
            }
        }
        return dataBinding.createWrapperHelper(wrapperClass, wrapperName, partNames, elTypeNames,
                partClasses);
    }

    private void ensureSize(List<?> lst, int idx) {
        while (idx >= lst.size()) {
            lst.add(null);
        }
    }
}
