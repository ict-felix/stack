/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.pathfinder;

import java.io.Serializable;

public class STP implements Serializable {

    private static final long serialVersionUID = 7826120661202142789L;

    public final String networkId; // MUST/MUST (Criteria/Result)
    public final String localId; // MUST(/OPT)/MUST
    public final IFTYPE ifType; // MUST. "ODU" or "LAMBDA"
    public final String tsId; // ODU:Criteria: OPT, ODU:Result: MUST, LAMBDA:
                              // null
    public final int tsWidth; // ODU: MUST, LAMBDA: null
    public final String lambdaId; // ODU: null, LAMBDA:Criteria: OPT,
                                  // LAMBDA:Result: MUST
    public final int lambdaWidth; // ODU: null, LAMBDA: MUST

    public STP(String networkId, String localId, IFTYPE iftype, String id, int width) {
        this.networkId = networkId;
        this.localId = localId;
        this.ifType = iftype;
        if (iftype == IFTYPE.LAMBDA) {
            this.tsId = null;
            this.tsWidth = -1;
            this.lambdaId = id;
            this.lambdaWidth = width;
        } else { // ODU
            this.tsId = id;
            this.tsWidth = width;
            this.lambdaId = null;
            this.lambdaWidth = -1;
        }
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(networkId);
        sb.append(":");
        sb.append(localId);
        sb.append("(");
        sb.append(ifType);
        if (ifType == IFTYPE.ODU) {
            sb.append(",");
            sb.append(tsId);
            sb.append(",");
            sb.append(tsWidth);
        } else { // LAMBDA
            sb.append(",");
            sb.append(lambdaId);
            sb.append(",");
            sb.append(lambdaWidth);
        }
        sb.append(")");
        return sb.toString();
    }
}
