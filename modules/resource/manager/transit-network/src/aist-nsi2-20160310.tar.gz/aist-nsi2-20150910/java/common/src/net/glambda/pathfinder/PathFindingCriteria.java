/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.pathfinder;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

public class PathFindingCriteria implements Serializable {

    private static final long serialVersionUID = 1391677773857063410L;

    public final String queryId; // MUST
    public final SUPERNETWORK superNetworkType; // MUST
    public final Calendar startTime; // MUST
    public final Calendar endTime; // MUST

    public final STP srcStp; // MUST, source STP
    public final STP dstStp; // MUST, destination STP
    public List<STP> ero = null; // OPT

    // Protection-related parameters
    public final boolean isProtection; // MUST, true or false
    public final STP protectionSrcSTP; // MUST if isProtection==true
    public final STP protectionDstSTP; // MUST if isProtection==true
    public List<STP> primary = null; // OPT
    public List<STP> secondary = null; // OPT

    public Map<String, Range> constraints = null; // OPT

    public PathFindingCriteria(String queryId, SUPERNETWORK snetId, Calendar start, Calendar end,
            STP src, STP dst, boolean isProtection) {
        this(queryId, snetId, start, end, src, dst, isProtection, null, null);
    }

    public PathFindingCriteria(String queryId, SUPERNETWORK snetId, Calendar start, Calendar end,
            STP src, STP dst, boolean isProtection, STP protectionSrcSTP, STP protectionDstSTP) {
        this.queryId = queryId;
        this.superNetworkType = snetId;
        this.startTime = start;
        this.endTime = end;
        this.srcStp = src;
        this.dstStp = dst;
        this.isProtection = isProtection;
        this.protectionSrcSTP = protectionSrcSTP;
        this.protectionDstSTP = protectionDstSTP;
    }

    public String toString() {
        String crlf = System.getProperty("line.separator");
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getName());
        sb.append(":");
        sb.append(queryId);
        sb.append(":");
        sb.append(superNetworkType);
        sb.append(crlf);
        sb.append(startTime.getTime().toString());
        sb.append("-");
        sb.append(endTime.getTime().toString());
        sb.append(crlf);
        sb.append("src: ");
        sb.append(srcStp);
        sb.append(crlf);
        sb.append("dst: ");
        sb.append(dstStp);
        if (ero != null) {
            sb.append(crlf);
            sb.append(toPathString("ero", ero));
        }
        if (isProtection) {
            sb.append(crlf);
            sb.append("psrc: ");
            sb.append(protectionSrcSTP);
            sb.append(crlf);
            sb.append("pdst: ");
            sb.append(protectionDstSTP);
            if (primary != null) {
                sb.append(crlf);
                sb.append(toPathString("primary", primary));
            }
            if (secondary != null) {
                sb.append(crlf);
                sb.append(toPathString("secondary", secondary));
            }
        }
        if (constraints != null) {
            for (String key : constraints.keySet()) {
                sb.append(",");
                sb.append(key);
                sb.append("-");
                sb.append(constraints.get(key));
            }
        }
        return sb.toString();
    }

    private String toPathString(String name, List<STP> list) {
        StringBuffer sb = new StringBuffer();
        sb.append(name);
        sb.append(": [");
        for (STP stp : list) {
            sb.append(stp.toString());
            sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
}
