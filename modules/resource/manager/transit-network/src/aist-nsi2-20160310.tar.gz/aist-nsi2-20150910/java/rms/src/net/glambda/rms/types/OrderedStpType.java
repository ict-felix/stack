/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.glambda.rms.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 *                 A Service Termination Point (STP) that can be ordered in a list for
 *                 use in PathObject definition.
 *     
 *                 Attributes:
 *     
 *                 order - Order attribute is provided only when the STP is part of an
 *                 orderedStpList.
 *     
 *                 Elements:
 *     
 *                 stp - The Service Termination Point (STP).
 *             
 * 
 * <p>Java class for OrderedStpType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderedStpType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="stp" type="{http://schemas.ogf.org/nsi/2013/07/services/types}StpType"/>
 *       &lt;/sequence>
 *       &lt;attribute name="order" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderedStpType", namespace = "http://schemas.ogf.org/nsi/2013/07/services/types", propOrder = {
    "stp"
})
public class OrderedStpType {

    @XmlElement(required = true)
    protected StpType stp;
    @XmlAttribute(name = "order", required = true)
    protected int order;

    /**
     * Gets the value of the stp property.
     * 
     * @return
     *     possible object is
     *     {@link StpType }
     *     
     */
    public StpType getStp() {
        return stp;
    }

    /**
     * Sets the value of the stp property.
     * 
     * @param value
     *     allowed object is
     *     {@link StpType }
     *     
     */
    public void setStp(StpType value) {
        this.stp = value;
    }

    /**
     * Gets the value of the order property.
     * 
     */
    public int getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     * 
     */
    public void setOrder(int value) {
        this.order = value;
    }

}
