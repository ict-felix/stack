/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.List;

import javax.xml.ws.Holder;

import net.glambda.nsi2.util.NSIPortManager;

import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class ProviderPortWithHeader implements ConnectionProviderPort {

    private static final NSIPortManager portMgr = NSIPortManager.getInstance();

    private final CommonHeaderType header;
    private final ConnectionProviderPort provider;

    public ProviderPortWithHeader(CommonHeaderType header, ConnectionProviderPort provider) {
        this.provider = provider;
        this.header = header;
    }

    @Override
    public void reserve(Holder<String> connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.reserve(connectionId, globalReservationId, description, criteria);
        }
    }

    @Override
    public void reserveCommit(String connectionId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.reserveCommit(connectionId);
        }
    }

    @Override
    public void reserveAbort(String connectionId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.reserveAbort(connectionId);
        }
    }

    @Override
    public void provision(String connectionId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.provision(connectionId);
        }
    }

    @Override
    public void release(String connectionId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.release(connectionId);
        }
    }

    @Override
    public void terminate(String connectionId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.terminate(connectionId);
        }
    }

    @Override
    public GenericAcknowledgmentType querySummary(QueryType querySummary) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            return provider.querySummary(querySummary);
        }
    }

    @Override
    public QuerySummaryConfirmedType querySummarySync(QueryType querySummarySync) throws Error {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            return provider.querySummarySync(querySummarySync);
        }
    }

    @Override
    public GenericAcknowledgmentType queryRecursive(QueryType queryRecursive)
            throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            return provider.queryRecursive(queryRecursive);
        }
    }

    @Override
    public List<QueryResultResponseType> queryResultSync(String connectionId, Long startResultId,
            Long endResultId) throws Error {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public QueryNotificationConfirmedType queryNotificationSync(
            QueryNotificationType queryNotificationSync) throws Error {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            return provider.queryNotificationSync(queryNotificationSync);
        }
    }

    @Override
    public void queryNotification(String connectionId, Long startNotificationId,
            Long endNotificationId) throws ServiceException {
        synchronized (provider) {
            portMgr.setCommonHeader(provider, header);
            provider.queryNotification(connectionId, startNotificationId, endNotificationId);
        }
    }

    @Override
    public void queryResult(String connectionId, Long startResultId, Long endResultId)
            throws ServiceException {
        // TODO Auto-generated method stub

    }
}
