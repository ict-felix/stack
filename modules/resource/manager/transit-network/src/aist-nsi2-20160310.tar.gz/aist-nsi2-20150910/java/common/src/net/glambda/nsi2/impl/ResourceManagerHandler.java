/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import net.glambda.nsi2.converter.ToRMS;
import net.glambda.nsi2.converter.ToNSI2;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.rms.NSI2ResourceManagerBase;
import net.glambda.rms.Notifier;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;

public class ResourceManagerHandler extends SampleProviderHandler {

    private final WholeResourceManager resourceManager;
    private final Notifier notifier;

    public ResourceManagerHandler(NSI2ResourceManagerBase resourceManager) {
        this.resourceManager = new WholeResourceManager(resourceManager);
        this.notifier = new SampleNotifier(this);
        this.resourceManager.setNotifier(this.notifier);
    }

    @Override
    public void reserve(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        super.reserve(arg, connectionId, globalReservationId, description, criteria);
        try {
            resourceManager.reserve(ToRMS.convert(arg.header()), connectionId, globalReservationId,
                    description, ToRMS.convert(criteria));
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void modify(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        super.modify(arg, connectionId, globalReservationId, description, criteria);
        try {
            if (criteria.getSchedule() == null && criteria.getAny().isEmpty()) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                        connectionId, "no modification parameters specified");
            }
            resourceManager.modify(ToRMS.convert(arg.header()), connectionId, globalReservationId,
                    description, ToRMS.convert(criteria));
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void reserveCommit(ProviderArgument arg, String connectionId) throws ServiceException {
        super.reserveCommit(arg, connectionId);
        try {
            resourceManager.commit(ToRMS.convert(arg.header()), connectionId);
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void reserveAbort(ProviderArgument arg, String connectionId) throws ServiceException {
        super.reserveAbort(arg, connectionId);
        try {
            resourceManager.abort(ToRMS.convert(arg.header()), connectionId);
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void provision(ProviderArgument arg, String connectionId) throws ServiceException {
        super.provision(arg, connectionId);
        try {
            resourceManager.provision(ToRMS.convert(arg.header()), connectionId);
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void release(ProviderArgument arg, String connectionId) throws ServiceException {
        super.release(arg, connectionId);
        try {
            resourceManager.release(ToRMS.convert(arg.header()), connectionId);
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

    @Override
    public void terminate(ProviderArgument arg, String connectionId) throws ServiceException {
        super.terminate(arg, connectionId);
        try {
            resourceManager.terminate(ToRMS.convert(arg.header()), connectionId);
        } catch (net.glambda.rms.types.ServiceException e) {
            throw ToNSI2.convert(e);
        }
    }

}
