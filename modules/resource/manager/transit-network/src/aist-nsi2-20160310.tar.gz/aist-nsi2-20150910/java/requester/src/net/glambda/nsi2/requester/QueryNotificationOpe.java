/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.util.NSITextDump;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class QueryNotificationOpe extends OpeBase {

    public final static String OPT_SYNC = "S";
    public final static String OPT_START = "s";
    public final static String OPT_END = "e";

    protected void addOptions(Options options) {
        addConnIDOption(options);

        OptionBuilder.hasArgs(0);
        OptionBuilder.withArgName("sync");
        OptionBuilder.withDescription("Call Sync operation if set (default: not set, async)");
        options.addOption(OptionBuilder.create(OPT_SYNC));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("startNotificationId");
        OptionBuilder.withDescription("query start NotificationId (default: not set, meanes 0)");
        options.addOption(OptionBuilder.create(OPT_START));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("endNotificationId");
        OptionBuilder.withDescription("query end NotificationId (default: not set, meanes all)");
        options.addOption(OptionBuilder.create(OPT_END));
    }

    private Long getInteger(CommandLine cmd, String opt) {
        String v = cmd.getOptionValue(opt);
        if (v != null) {
            return Long.parseLong(v);
        } else {
            return null;
        }
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        String connectionId = getConnectionID(cmd);
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);

        boolean isSync = cmd.hasOption(OPT_SYNC);
        Long start = getInteger(cmd, OPT_START);
        Long end = getInteger(cmd, OPT_END);
        log(cmd, "**** queryNotification request ****");
        log(cmd, NSITextDump.toString(header, connectionId, start, end));
        if (isSync) {
            QueryNotificationType req = new QueryNotificationType();
            req.setConnectionId(connectionId);
            req.setStartNotificationId(start);
            req.setEndNotificationId(end);
            QueryNotificationConfirmedType conf;
            try {
                conf = port.queryNotificationSync(req);
                log(cmd, "**** queryNotification response ****");
                log(cmd, NSITextDump.toString(header, conf));
            } catch (Error e) {
                e.printStackTrace();
            }
        } else {
            port.queryNotification(connectionId, start, end);
        }
    }

}
