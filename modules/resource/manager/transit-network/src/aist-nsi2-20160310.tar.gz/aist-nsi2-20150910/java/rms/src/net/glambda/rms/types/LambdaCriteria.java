/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.rms.types;

public class LambdaCriteria extends CriteriaBase {

    // source and dest STPs
    protected StpType sourceSTP;
    protected StpType destSTP;

    // DOPN service-specific parameters
    protected String superNetworkType;
    protected boolean isProtection;
    protected StpType secondarySourceSTP;
    protected StpType secondaryDestSTP;

    // PathFinding result information
    protected String pathType;
    protected int pathOrder;

    // Stp-related parameters
    protected String sourceIfType;
    protected String destIfType;
    protected int sourceLambdaId;
    protected int destLambdaId;
    protected int sourceLambdaWidth;
    protected int destLambdaWidth;

    public StpType getSourceSTP() {
        return sourceSTP;
    }

    public void setSourceSTP(StpType sourceSTP) {
        this.sourceSTP = sourceSTP;
    }

    public StpType getDestSTP() {
        return destSTP;
    }

    public void setDestSTP(StpType destSTP) {
        this.destSTP = destSTP;
    }

    public String getSuperNetworkType() {
        return superNetworkType;
    }

    public void setSuperNetworkType(String superNetworkType) {
        this.superNetworkType = superNetworkType;
    }

    public boolean isProtection() {
        return isProtection;
    }

    public void setProtection(boolean isProtection) {
        this.isProtection = isProtection;
    }

    public StpType getSecondarySourceSTP() {
        return secondarySourceSTP;
    }

    public void setSecondarySourceSTP(StpType secondarySourceSTP) {
        this.secondarySourceSTP = secondarySourceSTP;
    }

    public StpType getSecondaryDestSTP() {
        return secondaryDestSTP;
    }

    public void setSecondaryDestSTP(StpType secondaryDestSTP) {
        this.secondaryDestSTP = secondaryDestSTP;
    }

    public String getPathType() {
        return pathType;
    }

    public void setPathType(String pathType) {
        this.pathType = pathType;
    }

    public int getPathOrder() {
        return pathOrder;
    }

    public void setPathOrder(int pathOrder) {
        this.pathOrder = pathOrder;
    }

    public String getSourceIfType() {
        return sourceIfType;
    }

    public void setSourceIfType(String sourceIfType) {
        this.sourceIfType = sourceIfType;
    }

    public String getDestIfType() {
        return destIfType;
    }

    public void setDestIfType(String destIfType) {
        this.destIfType = destIfType;
    }

    public int getSourceLambdaId() {
        return sourceLambdaId;
    }

    public void setSourceLambdaId(int sourceLambdaId) {
        this.sourceLambdaId = sourceLambdaId;
    }

    public int getDestLambdaId() {
        return destLambdaId;
    }

    public void setDestLambdaId(int destLambdaId) {
        this.destLambdaId = destLambdaId;
    }

    public int getSourceLambdaWidth() {
        return sourceLambdaWidth;
    }

    public void setSourceLambdaWidth(int sourceLambdaWidth) {
        this.sourceLambdaWidth = sourceLambdaWidth;
    }

    public int getDestLambdaWidth() {
        return destLambdaWidth;
    }

    public void setDestLambdaWidth(int destLambdaWidth) {
        this.destLambdaWidth = destLambdaWidth;
    }

}
