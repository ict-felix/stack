/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jline.console.ConsoleReader;
import jline.console.completer.ArgumentCompleter;
import jline.console.completer.Completer;
import jline.console.completer.NullCompleter;
import jline.console.completer.StringsCompleter;
import jline.console.history.FileHistory;
import net.glambda.nsi2.impl.SampleRequester;
import net.glambda.nsi2.requester.NSIClientUtil;
import net.glambda.nsi2.requester.SimpleNSIRequester;
import net.glambda.nsi2.requester.OpeBase;
import net.glambda.nsi2.requester.ProvisionOpe;
import net.glambda.nsi2.requester.QueryOpe;
import net.glambda.nsi2.requester.ReleaseOpe;
import net.glambda.nsi2.requester.ReserveOpe;
import net.glambda.nsi2.requester.TerminateOpe;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.nsi2.util.SecurityUtil;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;

public class SimpleNSIRequester {

    static final String OPT_PROV_NAME = "P";
    static final String OPT_PROV_URI = "p";
    static final String OPT_REQ_NAME = "R";
    static final String OPT_REQ_URI = "r";
    static final String OPT_DSCV_URI = "d";

    private static Options getOptions() {
        Options options = new Options();

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("providerNSAname");
        OptionBuilder.isRequired(true);
        OptionBuilder.withDescription("ProviderNSA name (\"aist.ets\", \"starlight.ets\", etc)");
        options.addOption(OptionBuilder.create(OPT_PROV_NAME));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("providerURI");
        OptionBuilder.isRequired(true);
        OptionBuilder.withDescription("URI of target Provider");
        options.addOption(OptionBuilder.create(OPT_PROV_URI));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("requesterNSAname");
        OptionBuilder.isRequired(true);
        OptionBuilder.withDescription("RequesterNSA name (\"Aruba\", \"Bonaire\", etc)");
        options.addOption(OptionBuilder.create(OPT_REQ_NAME));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("requesterURI");
        OptionBuilder.isRequired(false); // not required if it's behind NAT
        OptionBuilder.withDescription("URI of Requester (open by this program)");
        options.addOption(OptionBuilder.create(OPT_REQ_URI));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("discoveryURI");
        OptionBuilder.isRequired(false);
        OptionBuilder.withDescription("URI of Discovery Provider");
        options.addOption(OptionBuilder.create(OPT_DSCV_URI));

        OptionBuilder.withDescription("Show this help");
        options.addOption(OptionBuilder.create("h"));

        return options;
    }

    private static final Options cmdOptions = getOptions();

    protected static Options getMainCmdOptions() {
        return cmdOptions;
    }

    private final LinkedHashMap<String, OpeBase> opeMap = new LinkedHashMap<String, OpeBase>();
    private ConnectionProviderPort provider = null;

    public SimpleNSIRequester() {
        this.opeMap.put("reserve", new ReserveOpe());
        this.opeMap.put("modify", new ModifyOpe());
        this.opeMap.put("commit", new CommitOpe());
        this.opeMap.put("abort", new AbortOpe());
        this.opeMap.put("provision", new ProvisionOpe());
        this.opeMap.put("release", new ReleaseOpe());
        this.opeMap.put("terminate", new TerminateOpe());
        this.opeMap.put("query", new QueryOpe());
        this.opeMap.put("queryNotification", new QueryNotificationOpe());
        this.opeMap.put("TERMINATE", new TerminateGlobalIdOpe());
        this.opeMap.put("TERMINATEALL", new TerminateAllOpe());
    }

    protected void addOpe(String name, OpeBase ope) {
        this.opeMap.put(name, ope);
    }

    private ConnectionProviderPort connectToProvider(CommandLine mainCmd) throws Exception {
        String providerURI = mainCmd.getOptionValue(OPT_PROV_URI, null);
        ConnectionProviderPort provider = NSIUtil.getProviderPort(providerURI);
        return provider;
    }

    protected Completer makeNetLocalCompletor(CommandLine mainCmd,
            LinkedHashMap<String, OpeBase> opeMap) {
        return new StringsCompleter(new String[] { "net1:local1?vlan=1780",
                "net1:local2?vlan=1780", "net2:local3?vlan=1780", "net2:local4?vlan=1780" });
    }

    private StringsCompleter makeIntRangeCompletor(int min, int max) {
        String[] vals = new String[max - min + 1];
        for (int n = min, i = 0; n <= max; n++, i++) {
            vals[i] = Integer.toString(n);
        }
        return new StringsCompleter(vals);
    }

    protected Completer makeCompletor(CommandLine mainCmd, LinkedHashMap<String, OpeBase> opeMap) {
        Completer compOp = new StringsCompleter(opeMap.keySet().toArray(new String[0]));
        Completer stpComp = makeNetLocalCompletor(mainCmd, opeMap);
        if (stpComp == null) {
            System.err.println("PROGRAM ERROR: makeNetLocalCompletor");
            System.exit(1);
        }
        Completer comps[] =
                { compOp, new StringsCompleter(new String[] { "-s" }), stpComp,
                        new StringsCompleter(new String[] { "-d" }), stpComp,
                        new StringsCompleter(new String[] { "-o" }), makeIntRangeCompletor(1, 3),
                        new StringsCompleter(new String[] { "-m" }), makeIntRangeCompletor(1, 5),
                        new StringsCompleter(new String[] { "-b" }),
                        new StringsCompleter(new String[] { "200", "500" }), new NullCompleter() };
        return new ArgumentCompleter(comps);
    }

    private ConsoleReader makeReader(CommandLine mainCmd, LinkedHashMap<String, OpeBase> opeMap)
            throws Exception {
        // https://github.com/jline/jline2
        ConsoleReader reader = new ConsoleReader();
        FileHistory history = new FileHistory(new File("nsirequester.history"));
        reader.setHistory(history);
        reader.setHistoryEnabled(true);
        reader.addCompleter(makeCompletor(mainCmd, opeMap));
        reader.setAutoprintThreshold(500); // [msec]
        history.setMaxSize(100); // history entry
        // NOTE: don't forget to call "history.flush()" after each execution
        return reader;
    }

    protected SampleRequester getRequester() throws Exception {
        return new SampleRequester();
    }

    private SampleRequester requester = null;

    private void startRequester(CommandLine mainCmd) throws Exception {
        OpeBase.setParams(mainCmd);
        String requesterURI = mainCmd.getOptionValue(OPT_REQ_URI);
        if (requesterURI != null) {
            requester = getRequester();
            SecurityUtil.publish(requesterURI, requester);
        } else {
            System.err.println("ConnectionRequesterPort doesn't launched because -" + OPT_REQ_URI
                    + " option is not specified");
        }
    }

    private static final Pattern ARG = Pattern.compile("\"([^\"]+)\"|([^ ]+)");

    private String[] splitLine(String line) {
        LinkedList<String> args = new LinkedList<String>();
        Matcher m = ARG.matcher(line);
        while (m.find()) {
            if (m.group(1) != null) {
                args.add(m.group(1));
            } else {
                args.add(m.group(2));
            }
        }
        return args.toArray(new String[0]);
    }

    protected boolean parseLine(String line) throws Exception {
        if (line == null) {
            return false;
        }
        line = line.trim();
        if (line.isEmpty()) {
            return false;
        }
        String[] s = splitLine(line);
        OpeBase ope = opeMap.get(s[0]);
        if (ope != null) {
            String[] cmdArgs = new String[s.length - 1];
            System.arraycopy(s, 1, cmdArgs, 0, cmdArgs.length);
            CommandLine cmd = NSIClientUtil.args2cmd(s[0], cmdArgs, ope.getOptions());
            if (cmd == null) {
                return false;
            }
            if (requester != null) {
                requester.setSilentLog(cmd.hasOption(OpeBase.OPT_SILENT));
            }
            ope.operation(provider, cmd);
        } else if (s[0].equals("quit") || s[0].equals("exit")) {
            return true;
        } else {
            if (!s[0].equals("help")) {
                System.err.println("unknown command: " + s[0]);
            }
            String name = (s.length >= 2 ? s[1] : null);
            for (Entry<String, OpeBase> e : opeMap.entrySet()) {
                if (name != null && !name.equals(e.getKey())) {
                    continue;
                }
                if (e.getValue() != null) {
                    NSIClientUtil.printHelp(e.getKey(), e.getValue().getOptions());
                } else {
                    System.err.println("usage: " + e.getKey());
                }
            }
        }
        return false;
    }

    protected void init(CommandLine mainCmd) throws Exception {
        provider = connectToProvider(mainCmd);
        startRequester(mainCmd);
    }

    protected void mainLoop(CommandLine mainCmd) throws Exception {
        ConsoleReader reader = makeReader(mainCmd, opeMap);
        FileHistory history = (FileHistory) reader.getHistory();
        boolean bQuit = false;
        while (!bQuit) {
            String line = reader.readLine("> ");
            try {
                history.flush(); // to flush to the file
                bQuit = parseLine(line);
            } catch (Exception e) {
                System.err.println("************ ERROR ************");
                if (e instanceof ServiceException) {
                    ServiceException ex = (ServiceException) e;
                    System.err.println(NSITextDump.toString(ex));
                } else {
                    System.err.println(e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        // NOTE: stop(), destroy() don't stop all Web service threads, so must
        // call System.exit(0) to exit.
        System.exit(0);
    }

    public static void main(String[] args) {
        SimpleNSIRequester app = new SimpleNSIRequester();
        CommandLine mainCmd = NSIClientUtil.args2cmd("NSIRequester", args, cmdOptions);
        if (mainCmd == null) {
            return;
        }

        try {
            app.init(mainCmd);
            app.mainLoop(mainCmd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
