/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;

public class PathFinderRequester extends SimpleNSIRequester {

    static final String OPT_RMI_HOST_PORT = "rmi";

    protected static Options getMainCmdOptions() {
        Options options = SimpleNSIRequester.getMainCmdOptions();

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("host:port:bindname");
        OptionBuilder.withDescription("RMI registry of PathFinder");
        options.addOption(OptionBuilder.create(OPT_RMI_HOST_PORT));

        return options;
    }

    public static void main(String[] args) {
        try {
            PathFinderRequester app = new PathFinderRequester();
            CommandLine mainCmd =
                    NSIClientUtil.args2cmd("PathFinderRequester", args, getMainCmdOptions());
            if (mainCmd == null) {
                return;
            }
            app.init(mainCmd);
            String hostPort = mainCmd.getOptionValue(OPT_RMI_HOST_PORT);
            if (hostPort != null) {
                PathFindOpe pf = new PathFindOpe(hostPort);
                app.addOpe("pathfind", pf);
                app.addOpe("pfreserve", new PathFinderReserve(pf));
            }
            app.mainLoop(mainCmd);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
