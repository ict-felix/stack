/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.util.List;
import java.util.LinkedList;

import net.glambda.nsi2.topology.AllPathFinder;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.SamplePathFinder;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;

public class PathOpe extends OpeBase {

    private final SamplePathFinder finder;

    public PathOpe(LinkedList<NSA> nsaList) throws Exception {
        this.finder = new SamplePathFinder(nsaList);
    }

    @Override
    protected void addOptions(Options options) {
        addSrcDestOption(options);
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        StpidVlan src = makeSTP(cmd, OPT_SRCSTP);
        StpidVlan dst = makeSTP(cmd, OPT_DSTSTP);
        if (src.vlan == NSIConstants.VLANID_NOTUSE || dst.vlan == NSIConstants.VLANID_NOTUSE) {
            throw new Exception("missing vlan parameter. add \"" + TypesBuilder.VLAN_MARK
                    + NSIConstants.VLANID_MIN + "\" etc");
        }
        LinkedList<Term> path = finder.search(src.stpid, src.vlan, dst.stpid, dst.vlan);
        List<List<Term>> pathList = new LinkedList<List<Term>>();
        pathList.add(path);
        AllPathFinder.output(pathList, 0);
    }

}
